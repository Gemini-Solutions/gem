package com.gemini.gembook.projections;

public interface EmployeeProfileProjection {
    String getName();
    String getEmail();
    String getDesignation();
}
