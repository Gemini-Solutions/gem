package com.gemini.gembook.utils;

/**
 * Created by ankur on 24/09/20
 */
public class Constants {

    public static final String EVENT_RESPONSE = "response";
    public static final int PAGINATED_POST_COUNT = 10;
    public static final int PAGINATED_COMMENT_COUNT = 20;
}
