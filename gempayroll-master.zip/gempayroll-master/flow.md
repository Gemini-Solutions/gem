1. options to choose from all option drop down for company to select its ctc
strucutre
2. ctc strucutre is what a company has chosen for its payroll
3. components in employee ctc will have to be in ctc strucutre

