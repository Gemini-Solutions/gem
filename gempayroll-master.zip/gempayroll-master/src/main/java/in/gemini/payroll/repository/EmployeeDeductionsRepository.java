package in.gemini.payroll.repository;

import in.gemini.payroll.entity.EmployeeDeductions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface EmployeeDeductionsRepository extends JpaRepository<EmployeeDeductions, Long> {

    Optional<EmployeeDeductions> findByEmployeeId(String employeeId);
    Optional<EmployeeDeductions> findByEmployeeIdAndDeduction(Integer employeeId, String deduction);
    Optional<EmployeeDeductions> deleteByEmployeeIdAndDeduction(Integer employeeId, String deduction);
    boolean existsByEmployeeIdAndDeduction(Integer employeeId, String deduction);
}
