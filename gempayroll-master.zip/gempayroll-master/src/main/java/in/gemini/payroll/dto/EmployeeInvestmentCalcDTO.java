package in.gemini.payroll.dto;

public class EmployeeInvestmentCalcDTO {
    private Long empInvestCalcId;
    private Integer employeeId;
    private Integer investmentViaId;
    private String calcType;
    private Integer amount;
    private String status;

    public Long getEmpInvestCalcId() {
        return empInvestCalcId;
    }

    public void setEmpInvestCalcId(Long empInvestCalcId) {
        this.empInvestCalcId = empInvestCalcId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public Integer getInvestmentViaId() {
        return investmentViaId;
    }

    public void setInvestmentViaId(Integer investmentViaId) {
        this.investmentViaId = investmentViaId;
    }

    public String getCalcType() {
        return calcType;
    }

    public void setCalcType(String calcType) {
        this.calcType = calcType;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}