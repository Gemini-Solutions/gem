package in.gemini.payroll.repository;

import in.gemini.payroll.entity.EmployeeMonthlyPayroll;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeMonthlyPayrollRepo extends JpaRepository<EmployeeMonthlyPayroll,Integer> {

    //when creating repo method make sure entity member name is used when creating findAll()
    Optional<List<EmployeeMonthlyPayroll>> findAllByEmployeeIdAndPayslipYearAndPayslipMonth(Integer employeeId, Integer payslipYear, Integer payslipMonth);

    boolean existsEmployeeMonthlyPayrollByEmployeeIdAndPayslipMonthAndPayslipYearAndPayslipComponent(Integer employeeId,Integer payslipMonth, Integer payslipYear, String payslipComponent);
    EmployeeMonthlyPayroll findByEmployeeIdAndPayslipMonthAndPayslipYearAndPayslipComponent(Integer employeeId,Integer payslipMonth, Integer payslipYear, String payslipComponent);

    boolean existsEmployeeMonthlyPayrollByPayslipMonthAndPayslipYear(Integer payslipMonth,Integer payslipYear);
}