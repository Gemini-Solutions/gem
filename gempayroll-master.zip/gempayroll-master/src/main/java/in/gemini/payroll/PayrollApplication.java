package in.gemini.payroll;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Scanner;

@SpringBootApplication
public class PayrollApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(PayrollApplication.class, args);
	}

}
