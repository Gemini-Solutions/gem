package in.gemini.payroll.services;

import java.io.File;
import java.sql.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.gemini.payroll.controller.CtcController;
import in.gemini.payroll.entity.EmployeeInvestmentProof;
import in.gemini.payroll.repository.InvestmentProofRepository;

@Service
public class EmployeeInvestmentProofService {
	
	@Value("${investment.doc.path}")
	private String investDocPath;
	
	@Autowired
	InvestmentProofRepository investProofRepo;
	
	private static final Logger log = LoggerFactory.getLogger(CtcController.class);
	
	public EmployeeInvestmentProof saveInvestmentProof(EmployeeInvestmentProof empInvestProof, MultipartFile file1, MultipartFile file2, MultipartFile file3, String employeeId) throws Exception {
		log.info("Inside save investment proof - ");
		final String directoryName = investDocPath + "/" + employeeId + "/";
		
		EmployeeInvestmentProof response = new EmployeeInvestmentProof();
		
		Optional<EmployeeInvestmentProof> oldEmpInvestProof = investProofRepo.findByEmpInvestDeclId(empInvestProof.getEmpInvestDeclId());
		if(oldEmpInvestProof.isPresent()) {
			throw new Exception("investment " + oldEmpInvestProof.get().getEmpInvestDeclId() + " already exist");
		}
		File directory = new File(String.valueOf(directoryName));
		if(!directory.exists()) {
			directory.mkdir();
		}
		
		if(file1!=null) {
			String fileName = directoryName+file1.getOriginalFilename();
			File file = new File(String.valueOf(fileName));
			file1.transferTo(file);
			empInvestProof.setProof1(fileName);
		}
		if(file2!=null) {
			String fileName = directoryName+empInvestProof.getProof2();
			File file = new File(String.valueOf(fileName));
			file2.transferTo(file);
			empInvestProof.setProof2(fileName);
		}
		if(file3!=null) {
			String fileName = directoryName+empInvestProof.getProof3();
			File file = new File(String.valueOf(fileName));
			file3.transferTo(file);
			empInvestProof.setProof3(fileName);
		}
		
		empInvestProof.setRowInsertDate(new Date(System.currentTimeMillis()));
		empInvestProof.setRowUpdateDate(new Date(System.currentTimeMillis()));
		empInvestProof.setRowUpdateBy(empInvestProof.getRowInsertBy());
		response = investProofRepo.save(empInvestProof);
		
		return response;
	}
	
	public void deleteInvestmentProof(Long id) throws Exception {
		
		Optional<EmployeeInvestmentProof> empInvestProof = investProofRepo.findById(id);
		if(!empInvestProof.isPresent()) {
			throw new Exception("Investment proof does not exist");
		}
		
		File file = new File(empInvestProof.get().getProof1());
		if(!file.exists()) {
			throw new Exception("investment proof does not exist in file system");
		}
		
		file.delete();
		investProofRepo.deleteById(id);
	}
	
	public EmployeeInvestmentProof updateProofStatus(Long id, String status, String userName) throws Exception {
		Optional<EmployeeInvestmentProof> empInvestProofOptional = investProofRepo.findById(id);
		if(!empInvestProofOptional.isPresent()) {
			throw new Exception("Investment proof does not exist");
		}
		EmployeeInvestmentProof empInvestProof = empInvestProofOptional.get();
		empInvestProof.setStatus(status);
		empInvestProof.setRowUpdateBy(userName);
		empInvestProof.setRowUpdateDate(new Date(System.currentTimeMillis()));
		
		return empInvestProof;
	}
}
