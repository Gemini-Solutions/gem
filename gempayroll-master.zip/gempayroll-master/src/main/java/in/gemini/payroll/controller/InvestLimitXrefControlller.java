package in.gemini.payroll.controller;


import in.gemini.payroll.Response.ResponseClass;

import in.gemini.payroll.entity.InvestmentLimitXref;
import in.gemini.payroll.services.InvestLimitXrefService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/InvestLimitXref")
public class InvestLimitXrefControlller {

    @Autowired
    private InvestLimitXrefService investLimitXrefService;

    private static final Logger log = LoggerFactory.getLogger(InvestLimitXrefControlller.class);

    // Nov 23, 2021
    // Aman: I don't think we need a post mapping in this and the name for the post mapping is a bit off with what we are following here
    // Nov 24, 2021 removing POST API and related methods

//    @PostMapping(value = "/New-Invest-Limit-Xref")
//    @ApiOperation(value = "Insert new Investment Limit")
//    public ResponseClass addNewInvestLimitXref(@RequestBody InvestmentLimitXref investmentLimitXref)
//    {
//        log.info("Inside addNewInvestLimitXref function, data :"+investmentLimitXref);
//        try {
//            InvestmentLimitXref response = investLimitXrefService.addNewInvestLimitXref(investmentLimitXref);
//            log.info("completed adding investment limit - " + investmentLimitXref);
//            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
//        }catch(Exception e) {
//            e.printStackTrace();
//            log.error("Error in adding investment limit - " + investmentLimitXref+
//                    "\nException : "+e);
//            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
//        }
//    }

    @GetMapping("/InvestLimitXref")
    // Oct 21, 2021 get max limit for an investment
    public ResponseClass getInvestLimitXrefBySection(@RequestParam String section) {
        log.info("REST inside getInvestLimitXrefBySection for section : {} ", section);

        try {
            return new ResponseClass(investLimitXrefService.getInvestmentLimitXrefBySection(section), "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.getLocalizedMessage();
            log.error("REST getInvestLimitXrefBySection Error retrieving section {}", section);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/allInvestLimitXref")
    @ApiOperation(value = "Get all Investment sections with their max limit")
    public ResponseClass getAllInvestLimitXref() {
        log.info("REST getAllInvestLimitXref start");
        List<InvestmentLimitXref> investmentLimitXrefList;
        try {
            investmentLimitXrefList = investLimitXrefService.getAllInvestLimitXrefs();
            log.info("REST getAllInvestLimitXref end with size {}", investmentLimitXrefList.size());
            return new ResponseClass(investmentLimitXrefList, "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST getAllInvestLimitXref ERROR {}", e.getMessage());
            return new ResponseClass(e.getLocalizedMessage(), "SUCCESS", HttpStatus.OK);

        }
    }
}
