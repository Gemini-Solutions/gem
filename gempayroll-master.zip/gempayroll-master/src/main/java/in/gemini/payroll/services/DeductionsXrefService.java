package in.gemini.payroll.services;

import in.gemini.payroll.entity.DeductionsXref;
import in.gemini.payroll.repository.DeductionsXrefRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DeductionsXrefService {

    @Autowired
    private DeductionsXrefRepository deductionsXrefRepository;

    private static final Logger log = LoggerFactory.getLogger(DeductionsXrefService.class);

    public DeductionsXref addNewDeduction(DeductionsXref deductionsXref) throws Exception {
        DeductionsXref response;
        log.info("Service addNewDeduction add new {}", deductionsXref);

        Optional<DeductionsXref> ded = deductionsXrefRepository.findById(deductionsXref.getDeduction());
        if (ded.isPresent()) {
            throw new Exception(deductionsXref.getDeduction() + " Deduction already present");
        }

        response = deductionsXrefRepository.save(deductionsXref);

        return response;
    }

    public List<DeductionsXref> getAllDeductions() throws Exception {
        log.info("Service getAllDeductions");

        List<DeductionsXref> data = deductionsXrefRepository.findAll();

        if (data.isEmpty()) {
            log.error("No data found in employee");
            throw new Exception(" No data found in Deduction");
        }

        return data;
    }

    public DeductionsXref getDeductionById(String id) throws Exception {
        log.info("Service get deductionById id {}", id);
        Optional<DeductionsXref> optional = deductionsXrefRepository.findById(id);

        // if data is not found
        if (!optional.isPresent()) {
            log.error("No data found in deduction for id {}", id);
            throw new Exception("deduction " + id + " does not exist.");
        }
        return optional.get();
    }

    public DeductionsXref updateDeduction(DeductionsXref deductionsXref) throws Exception {
        log.info("Service updateDeduction with id {}", deductionsXref.getDeduction());

        Optional<DeductionsXref> ded = deductionsXrefRepository.findById(deductionsXref.getDeduction());
        if (!ded.isPresent()) {
            log.error("Service updateDeduction failed. id {} does not exist", deductionsXref.getDeduction());
            throw new Exception(deductionsXref.getDeduction() + " deduction does not exist`");
        }
        return deductionsXrefRepository.save(deductionsXref);
    }

    public void deleteDeductionById(String id) throws Exception {

        log.info("Service deleteDeductionById having id {}", id);

        if (deductionsXrefRepository.existsById(id)) {
            log.info("Deduction {} found | Deleting", id);
            deductionsXrefRepository.deleteById(id);
            log.info("Deduction {} delete success", id);
        } else {
            log.error("Service deleteDeductionById : deduction {} does not exist", id);
            throw new Exception("Deduction " + id + " does not exist");
        }
    }
}
