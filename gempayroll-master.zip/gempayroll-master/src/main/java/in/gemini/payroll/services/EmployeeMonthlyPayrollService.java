package in.gemini.payroll.services;

import in.gemini.payroll.entity.EmployeeMonthlyPayroll;
import in.gemini.payroll.entity.PayrollCalc;
import in.gemini.payroll.repository.EmployeeMonthlyPayrollRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeMonthlyPayrollService {
    @Autowired
    EmployeeMonthlyPayrollRepo employeeMonthlyPayrollRepo;
    @Autowired
    PayrollService payrollService;

    private static final Logger log = LoggerFactory.getLogger(EmployeeMonthlyPayrollService.class);

    public Optional<List<EmployeeMonthlyPayroll>> getMonthlyPayslip(Integer employeeId, Integer payslipYear, Integer payslipMonth) {
        log.info("Inside get monthly payslip",employeeId,payslipYear,payslipMonth);
        return employeeMonthlyPayrollRepo.findAllByEmployeeIdAndPayslipYearAndPayslipMonth(employeeId,payslipYear,payslipMonth);
    }


    public List<EmployeeMonthlyPayroll> insertMonthlyPayslip(Integer employeeId, Integer payslipYear, Integer payslipMonth) {
        log.info("Inside insert monthly payroll",employeeId,payslipYear,payslipMonth);
        List<PayrollCalc> payrollCalcList = payrollService.getPayrollCalcByEmpId(employeeId);
        List<EmployeeMonthlyPayroll> employeeMonthlyPayrollList = new ArrayList<>();
        for(int i = 0; i<payrollCalcList.size(); i++){
            EmployeeMonthlyPayroll employeeMonthlyPayroll = new EmployeeMonthlyPayroll();
            employeeMonthlyPayroll.setEmployeeId(employeeId);
            employeeMonthlyPayroll.setPayslipYear(payslipYear);
            employeeMonthlyPayroll.setPayslipMonth(payslipMonth);
            //Todo verify the inserter
            employeeMonthlyPayroll.setRowInsertBy("Unit Test Developer");
            employeeMonthlyPayroll.setRowInsertDate(new Date());
            //Todo verify the updater
            employeeMonthlyPayroll.setRowUpdateBy("Unit Test Developer");
            employeeMonthlyPayroll.setRowUpdateDate(new Date());
            employeeMonthlyPayroll.setPayslipComponent((payrollCalcList.get(i).getComponent()));
            employeeMonthlyPayroll.setComponentAmount(Double.valueOf(payrollCalcList.get(i).getValue()));
            employeeMonthlyPayrollList.add(employeeMonthlyPayroll);
        }
        List<EmployeeMonthlyPayroll> employeeMonthlyPayrollResponse = employeeMonthlyPayrollRepo.saveAll(employeeMonthlyPayrollList);
        return employeeMonthlyPayrollResponse;
    }

    // Dec 22, 2021 Old payslip records that already exist will be updated with the latest changes.
    // Important to note here that components that got
    // added for an employee in CTC details will start to be reflected in past payslips if updated.
    public void batchPayslipInsertForMonthAndYear(Integer payslipYear, Integer payslipMonth) throws Exception {

        // Get payroll details for all employees
        List<PayrollCalc> allPayrollCalcList = payrollService.getPayrollCalc();

        // Based on month and year, calculation logic placed here.
        // For now considering all employees have full attendance and all working days are paid.
        List<EmployeeMonthlyPayroll> employeeMonthlyPayrollList = new ArrayList<>();

        for (PayrollCalc payrollCalc : allPayrollCalcList) {
            if (employeeMonthlyPayrollRepo.
                    existsEmployeeMonthlyPayrollByEmployeeIdAndPayslipMonthAndPayslipYearAndPayslipComponent(
                            payrollCalc.getEmployeeId(), payslipMonth, payslipYear, payrollCalc.getComponent())
            ) {
                EmployeeMonthlyPayroll employeeMonthlyPayroll = employeeMonthlyPayrollRepo.
                        findByEmployeeIdAndPayslipMonthAndPayslipYearAndPayslipComponent(
                                payrollCalc.getEmployeeId(), payslipMonth, payslipYear, payrollCalc.getComponent()
                        );
                employeeMonthlyPayroll.setComponentAmount(Double.valueOf(payrollCalc.getValue()));
                employeeMonthlyPayroll.setRowUpdateBy("Unit ");
                employeeMonthlyPayroll.setRowUpdateDate(new Date());
                employeeMonthlyPayrollList.add(employeeMonthlyPayroll);
                continue;
            }
            EmployeeMonthlyPayroll employeeMonthlyPayroll = new EmployeeMonthlyPayroll();
            employeeMonthlyPayroll.setEmployeeId(payrollCalc.getEmployeeId());
            employeeMonthlyPayroll.setPayslipYear(payslipYear);
            employeeMonthlyPayroll.setPayslipMonth(payslipMonth);
            //Todo verify the inserter
            employeeMonthlyPayroll.setRowInsertBy("Unit Test Developer");
            employeeMonthlyPayroll.setRowInsertDate(new Date());
            //Todo verify the updater
            employeeMonthlyPayroll.setRowUpdateBy("Unit Test Developer");
            employeeMonthlyPayroll.setRowUpdateDate(new Date());
            employeeMonthlyPayroll.setPayslipComponent((payrollCalc.getComponent()));
            employeeMonthlyPayroll.setComponentAmount(Double.valueOf(payrollCalc.getValue()));
            employeeMonthlyPayrollList.add(employeeMonthlyPayroll);
        }
        employeeMonthlyPayrollRepo.saveAll(employeeMonthlyPayrollList);
    }

}
