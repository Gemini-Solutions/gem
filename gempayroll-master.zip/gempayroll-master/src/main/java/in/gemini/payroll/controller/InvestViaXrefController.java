package in.gemini.payroll.controller;


import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.InvestmentViaXref;
import in.gemini.payroll.services.InvestViaXrefService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/investViaXref")
public class InvestViaXrefController {

    @Autowired
    private InvestViaXrefService investViaXrefService;

    private static final Logger log= LoggerFactory.getLogger(InvestViaXrefController.class);

    @PostMapping("/new-invest-via-xref")
    @ApiOperation(value = "add a new Invest Via Xref in Payroll Database")
    public ResponseClass addNewInvestViaXref(@RequestBody InvestmentViaXref investmentViaXref)
    {
        log.info("Inside addNewInvestLimitXref function,data : "+investmentViaXref);
        try {
            InvestmentViaXref response = investViaXrefService.addNewInvestViaXref(investmentViaXref);
            log.info("completed adding investment via Xref for section - " +
                    investmentViaXref.getSection()+
                    " and Type : "+investmentViaXref.getInvestmentType());
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in adding investment via Xref - " + investmentViaXref.toString()+
                    "\nException : "+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
