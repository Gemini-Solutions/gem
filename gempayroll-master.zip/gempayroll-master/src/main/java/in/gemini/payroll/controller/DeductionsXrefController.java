package in.gemini.payroll.controller;

import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.DeductionsXref;
import in.gemini.payroll.services.DeductionsXrefService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/deductions-xref")
public class DeductionsXrefController {

    @Autowired
    private DeductionsXrefService deductionsXrefService;

    private static final Logger log = LoggerFactory.getLogger(DeductionsXrefController.class);

    @PostMapping("/createDeduction")
    @ApiOperation(value = "Insert new Employee details", notes = "Add a new deduction into payroll database. Pass JSON as request")
    public ResponseClass createNewDeduction(@RequestBody DeductionsXref deductionsXref) {
        log.info("REST create new deduction {}", deductionsXref);
        try {
            DeductionsXref response = deductionsXrefService.addNewDeduction(deductionsXref);
            log.info("REST create new deduction complete {} ", deductionsXref);
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping("/getAllDeduction")
    @ApiOperation(value = "Get all Deduction details", notes = "Get all deduction from payroll database")
    public ResponseClass getAllDeduction() {
        log.info("REST get all deductions");
        try {
            List<DeductionsXref> response = deductionsXrefService.getAllDeductions();
            log.info("REST get all deductions end with size {}", response.size());
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getDeduction/{id}")
    @ApiOperation(value = "Get deduction details for a given deduction")
    public ResponseClass getDeduction(@PathVariable("id") String id) {
        log.info("REST get deduction of id {}", id);
        try {
            DeductionsXref response = deductionsXrefService.getDeductionById(id);
            log.info("REST get deduction of id {} response {}", id, response);
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping(value = "/updateDeduction")
    @ApiOperation(value = "Insert new Employee details", notes = "Update already existing deduction into payroll. Request as all the details as JSON to update.")
    public ResponseClass updateDeduction(@RequestBody DeductionsXref deductionsXref) {
        log.info("REST updateDeduction of id {} as {}", deductionsXref.getDeduction(), deductionsXref);

        try {
            DeductionsXref response = deductionsXrefService.updateDeduction(deductionsXref);
            log.info("REST updateDeduction end {}", response);
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST updateDeduction Error: {}", e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @DeleteMapping(value = "/deleteDeductionById/{id}")
    @ApiOperation(value = "Delete deduction details", notes = "Delete deduction by providing deduction string")
    public ResponseClass deleteDeduction(@PathVariable String id) {
        log.info("REST delete deduction by id {}", id);
        try {
            deductionsXrefService.deleteDeductionById(id);
            log.info("REST delete employee by id end");
            return new ResponseClass("deduction " + id + " deletion successful", "SUCCESS", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST deleteDeductionById error {}", e.getMessage());
            return new ResponseClass("deduction deletion fail " + e.getMessage(), "FAIL", HttpStatus.OK);
        }
    }
}
