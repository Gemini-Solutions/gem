package in.gemini.payroll.services;


import in.gemini.payroll.entity.EmployeeDetails;
import in.gemini.payroll.entity.EmployeeInvestmentDeclaration;
import in.gemini.payroll.repository.EmpInvestDeclareRepo;
import in.gemini.payroll.repository.EmployeeDetailsRepository;
import in.gemini.payroll.repository.InvestLimitXrefRepo;
import in.gemini.payroll.repository.InvestViaXrefRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class EmpInvestDeclarationService {

    @Autowired
    private EmpInvestDeclareRepo empInvestDeclareRepo;
    @Autowired
    private EmployeeDetailsRepository employeeDetailsRepository;

    @Autowired
    private InvestViaXrefRepo investViaXrefRepo;
    @Autowired
    private InvestLimitXrefRepo investLimitXrefRepo;
    private static final Logger log = LoggerFactory.getLogger(EmpInvestDeclarationService.class);

    public EmployeeInvestmentDeclaration addInvestmentDeclaration(EmployeeInvestmentDeclaration employeeInvestmentDeclaration) throws Exception {

        log.info("Inside add Investment Declaration Service, data: {}",employeeInvestmentDeclaration);

        if(!employeeDetailsRepository.findById(employeeInvestmentDeclaration.getEmployeeId()).isPresent())
        {
            log.info("Employee with employee id {} does not exist.", employeeInvestmentDeclaration.getEmployeeId());
            throw new Exception("Employee with emoloyee id "+employeeInvestmentDeclaration.getEmployeeId()+" does not exist.");
        }
        if(!investViaXrefRepo.findById(employeeInvestmentDeclaration.getInvestmentViaId()).isPresent())
        {
            log.info("No Investment Via Xref data found with investmentViaId : {}", employeeInvestmentDeclaration.getInvestmentViaId());
            throw new Exception("No Investment Via Xref data found with investmentViaId : "+employeeInvestmentDeclaration.getInvestmentViaId());
        }

        //Avoiding any injection using employee investment declaration id
        if(employeeInvestmentDeclaration.getEmpInvestDeclId()!=null)
        {
            log.info("employee Investment declaration id is auto generated, don't push 'employee Investment declaration id' while creating");
            throw new Exception("employee Investment declaration id is auto generated, don't push 'employee Investment declaration id' while creating");
        }

        // TODO JAN 5, 2022 review handling of investment declaration limit to be set at 1.5 lakhs incase values
        //  exceed the limit. Marking below check condition as comment for to do task in phase 2.
        //checking if the investment limit exceeds or not
//        if(employeeInvestmentDeclaration.getAmount() > getLimitAmount(employeeInvestmentDeclaration))
//        {
//            log.info("Investment Declaration exceeds the limit, input amount : "+employeeInvestmentDeclaration.getAmount()+
//            " and Limit is : "+getLimitAmount(employeeInvestmentDeclaration).toString());
//            throw new Exception("Investment Declaration exceeds the limit, input amount : "+employeeInvestmentDeclaration.getAmount()+
//                    " and Limit is : "+getLimitAmount(employeeInvestmentDeclaration).toString());
//        }

        employeeInvestmentDeclaration.setRowUpdateBy(employeeInvestmentDeclaration.getRowInsertBy());
        employeeInvestmentDeclaration.setRowInsertDate(new Date(System.currentTimeMillis()));
        employeeInvestmentDeclaration.setRowUpdateDate(new Date(System.currentTimeMillis()));

        return empInvestDeclareRepo.save(employeeInvestmentDeclaration);

    }

    @Transactional(readOnly = true)
    public List<EmployeeInvestmentDeclaration> getAllInvestDeclaration() throws Exception {
        log.info("Inside getAllInvestDeclaration Service");
        List<EmployeeInvestmentDeclaration> employeeInvestmentDeclarationList = empInvestDeclareRepo.findAll();

        if(employeeInvestmentDeclarationList.isEmpty())
        {
            log.info("employee Investment list is empty");
            throw new Exception("employee Investment list is empty");
        }

        return  employeeInvestmentDeclarationList;

    }

    @Transactional(readOnly = true)
    public EmployeeInvestmentDeclaration getEmployeeInvestDeclaration(Long empDeclarationId) throws Exception {
        log.info("Inside getEmployeeInvestDeclaration Service, id : "+empDeclarationId);

        Optional<EmployeeInvestmentDeclaration> employeeInvestmentDeclaration = empInvestDeclareRepo.findById(empDeclarationId);
        if(!employeeInvestmentDeclaration.isPresent())
        {
            log.info("Employee Investment for given empDeclarationId : "+empDeclarationId + " is not present");
            throw new Exception("Employee Investment for given empDeclarationId : "+empDeclarationId + " is not present");
        }
        return employeeInvestmentDeclaration.get();
    }

    public void deleteEmployeeInvestmentDecById(Long empInvDecId) throws Exception {
        log.info("Inside deleteEmployeeInvestmentDecById Service, id: "+empInvDecId);

        Optional<EmployeeInvestmentDeclaration> employeeInvestmentDeclaration = empInvestDeclareRepo.findById(empInvDecId);

        if(!employeeInvestmentDeclaration.isPresent())
        {
            log.info("No Employee Investment exist with id: "+empInvDecId);
            throw new Exception("No Employee Investment exist with id: "+empInvDecId);
        }

        empInvestDeclareRepo.deleteById(empInvDecId);
    }


    public void updateEmployeeInvestmentDec(EmployeeInvestmentDeclaration employeeInvestmentDeclaration) throws Exception {

        log.info("Inside update Employee Investment Declaration, data: "+employeeInvestmentDeclaration);

        //checking if the employee id exist or not
        if(!employeeDetailsRepository.findById(employeeInvestmentDeclaration.getEmployeeId()).isPresent())
        {
            log.info("Employee id : "+employeeInvestmentDeclaration.getEmployeeId() + " does not exists");
            throw new Exception("Employee id : "+employeeInvestmentDeclaration.getEmployeeId() + " does not exists");
        }

        Optional<EmployeeInvestmentDeclaration> optionalEmployeeInvestmentDeclaration = empInvestDeclareRepo.findById(employeeInvestmentDeclaration.getEmpInvestDeclId());
        if(!optionalEmployeeInvestmentDeclaration.isPresent())
        {
            log.info("No employee Investment Declaration found with id: "+employeeInvestmentDeclaration.getEmpInvestDeclId());
            throw new Exception("No employee Investment Declaration found with id: "+employeeInvestmentDeclaration.getEmpInvestDeclId());
        }

        // TODO JAN 5, 2022 review handling of investment declaration limit to be set at 1.5 lakhs incase values
        //  exceed the limit. Marking below check condition as comment for to do task in phase 2.
        //checking if the investment limit exceeds or not
//        if(employeeInvestmentDeclaration.getAmount() > getLimitAmount(employeeInvestmentDeclaration))
//        {
//            log.info("Investment Declaration exceeds the limit, input amount : "+employeeInvestmentDeclaration.getAmount()+
//                    " and Limit is : "+getLimitAmount(employeeInvestmentDeclaration).toString());
//            throw new Exception("Investment Declaration exceeds the limit, input amount : "+employeeInvestmentDeclaration.getAmount()+
//                    " and Limit is : "+getLimitAmount(employeeInvestmentDeclaration).toString());
//        }

        optionalEmployeeInvestmentDeclaration.get().setEmployeeId(employeeInvestmentDeclaration.getEmployeeId());
        optionalEmployeeInvestmentDeclaration.get().setAmount(employeeInvestmentDeclaration.getAmount());
        optionalEmployeeInvestmentDeclaration.get().setInvestmentViaId(employeeInvestmentDeclaration.getInvestmentViaId());
        optionalEmployeeInvestmentDeclaration.get().setFiscal(employeeInvestmentDeclaration.getFiscal());
        optionalEmployeeInvestmentDeclaration.get().setRowUpdateBy(employeeInvestmentDeclaration.getRowUpdateBy());
        optionalEmployeeInvestmentDeclaration.get().setStatus(employeeInvestmentDeclaration.getStatus());
        optionalEmployeeInvestmentDeclaration.get().setRowUpdateDate(new Date(System.currentTimeMillis()));

        empInvestDeclareRepo.save(optionalEmployeeInvestmentDeclaration.get());
    }

    @Transactional(readOnly = true)
    public List<EmployeeInvestmentDeclaration> getEmployeeInvestDeclarationByEmpId(Integer employeeId) throws Exception {
        log.info("Inside get employee Invest declaration by employee id for id: "+employeeId);

        Optional<EmployeeDetails> employeeDetails = employeeDetailsRepository.findById(employeeId);
        if (!employeeDetails.isPresent())
        {
            log.info("No employee exist with employee id : "+employeeId);
            throw new Exception("No employee exist with employee id : "+employeeId);
        }

        List<EmployeeInvestmentDeclaration> optionalEmployeeInvestmentDeclarationList = empInvestDeclareRepo.findByEmployeeId(employeeId);
        if(optionalEmployeeInvestmentDeclarationList.isEmpty())
        {
            log.info("No employee declaration exist with employee id : "+employeeId);
            throw new Exception("No employee declaration exist with employee id : "+employeeId);
        }
        return optionalEmployeeInvestmentDeclarationList;
    }

    //this is a function to get the limit of a particular section according to InvestmentLimitXref
    private Integer getLimitAmount(EmployeeInvestmentDeclaration employeeInvestmentDeclaration)
    {

        Long id = employeeInvestmentDeclaration.getInvestmentViaId();
        String section = investViaXrefRepo.findById(id).get().getSection();
        Integer response = investLimitXrefRepo.findById(section).get().getInvestmentLimit();
        return response;
    }
}
