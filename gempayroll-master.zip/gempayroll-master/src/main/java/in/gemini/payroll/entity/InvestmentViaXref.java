package in.gemini.payroll.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="INVESTMENT_VIA_XREF", schema = "payroll",uniqueConstraints = @UniqueConstraint(columnNames = {"SECTION","INVESTMENT_TYPE"}))
@JsonIgnoreProperties(ignoreUnknown = true)
public class InvestmentViaXref {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "INVESTMENT_VIA_ID")
    private Long investmentViaId;

    @Column(name = "SECTION")
    private String section;

    @Column(name = "INVESTMENT_TYPE")
    private String investmentType;

    @Column(name = "INVESTMENT_DESCRIPTION")
    private String investmentDescription;

    @Column(name="ROW_INSERT_BY",nullable = false)
    private String rowInsertBy;

    @Column(name = "INVESTMENT_LABEL_NAME")
    private String investmentLabelName;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE",nullable = false)
    private Date rowInsertDate;

    @Column(name = "ROW_UPDATE_BY",nullable = false)
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE",nullable = false)
    private Date rowUpdateDate;


    public Long getInvestmentViaId() {
        return investmentViaId;
    }

    public void setInvestmentViaId(Long investmentViaId) {
        this.investmentViaId = investmentViaId;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getInvestmentType() {
        return investmentType;
    }

    public void setInvestmentType(String investmentType) {
        this.investmentType = investmentType;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    public String getInvestmentDescription() {
        return investmentDescription;
    }

    public void setInvestmentDescription(String investmentDescription) {
        this.investmentDescription = investmentDescription;
    }

    public String getInvestmentLabelName() {
        return investmentLabelName;
    }

    public void setInvestmentLabelName(String investmentLabelName) {
        this.investmentLabelName = investmentLabelName;
    }


    @Override
    public String toString() {
        return "InvestmentViaXref{" +
                "investmentViaId=" + investmentViaId +
                ", section='" + section + '\'' +
                ", investmentType='" + investmentType + '\'' +
                ", rowInsertBy='" + rowInsertBy + '\'' +
                ", rowInsertDate=" + rowInsertDate +
                ", rowUpdateBy='" + rowUpdateBy + '\'' +
                ", rowUpdateDate=" + rowUpdateDate +
                '}';
    }
}
