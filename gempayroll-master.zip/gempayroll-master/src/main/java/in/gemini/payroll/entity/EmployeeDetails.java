package in.gemini.payroll.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "employee_details", schema = "payroll")
public class EmployeeDetails {


    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    @Id
    @Column(name = "EMPLOYEE_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer employeeId;

    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "PAN")
    private String pan;
    @Column(name = "AADHAAR")
    private String aadhaar;
    @Column(name = "DATE_OF_BIRTH")
    @ApiModelProperty(value = "Date As String", example = "31/05/2020")
    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Kolkata")
    private Date dateOfBirth;
    @ApiModelProperty(value = "Date As String", example = "31/05/2020")
    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Kolkata")
    @Column(name = "DATE_OF_JOINING")
    private Date dateOfJoining;
    @ApiModelProperty(value = "Date As String", example = "31/05/2020")
    @JsonFormat(pattern = "dd/MM/yyyy", timezone = "Asia/Kolkata")
    @Column(name = "DATE_OF_EXIT")
    private Date dateOfExit;
    @Column(name = "PERMENANT_ADDRESS")
    private String permenantAddress = "NA";

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getAadhaar() {
        return aadhaar;
    }

    public void setAadhaar(String aadhaar) {
        this.aadhaar = aadhaar;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Date getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(Date dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public Date getDateOfExit() {
        return dateOfExit;
    }

    public void setDateOfExit(Date dateOfExit) {
        this.dateOfExit = dateOfExit;
    }

    public String getPermenantAddress() {
        return permenantAddress;
    }

    public void setPermenantAddress(String permenantAddress) {
        this.permenantAddress = permenantAddress;
    }

    public String getCorrespondenceAddress() {
        return correspondenceAddress;
    }

    public void setCorrespondenceAddress(String correspondenceAddress) {
        this.correspondenceAddress = correspondenceAddress;
    }

    public String getUanNo() {
        return uanNo;
    }

    public void setUanNo(String uanNo) {
        this.uanNo = uanNo;
    }

    public String getPfNo() {
        return pfNo;
    }

    public void setPfNo(String pfNo) {
        this.pfNo = pfNo;
    }

    public String getBankAcctNo() {
        return bankAcctNo;
    }

    public void setBankAcctNo(String bankAcctNo) {
        this.bankAcctNo = bankAcctNo;
    }

    public String getBankAcctName() {
        return bankAcctName;
    }

    public void setBankAcctName(String bankAcctName) {
        this.bankAcctName = bankAcctName;
    }

    public String getBankAcctAddress() {
        return bankAcctAddress;
    }

    public void setBankAcctAddress(String bankAcctAddress) {
        this.bankAcctAddress = bankAcctAddress;
    }

    public String getBankIFSC() {
        return bankIFSC;
    }

    public void setBankIFSC(String bankIFSC) {
        this.bankIFSC = bankIFSC;
    }

    @Column(name = "CORRESPONDENCE_ADDRESS")
    private String correspondenceAddress = "NA";
    @Column(name = "UAN_NO")
    private String uanNo;
    @Column(name = "PF_NO")
    private String pfNo;
    @Column(name = "BANK_ACCT_NO")
    private String bankAcctNo;
    @Column(name = "BANK_ACCT_NAME")
    private String bankAcctName;
    @Column(name = "BANK_ACCT_ADDRESS")
    private String bankAcctAddress;
    @Column(name = "BANK_IFSC")
    private String bankIFSC;

    @ApiModelProperty(value = "value as char(M/N) Metropolitan / Non-Metropolitan ", example = "M ")
    @JsonFormat(pattern = "M/N")
    @Column(name = "CITY_TYPE")
    private char cityType;

    @ApiModelProperty(value = " Status of the Employee Active or Inactive", example = "ACTIVE")
    @JsonFormat(pattern = "ACTIVE/INACTIVE")
    @Column(name = "STATUS")
    private String status;

    @Column(name = "ROW_INSERT_BY")
    private String rowInsertBy;

    @ApiModelProperty(value = "Date As String", example = "31/05/2020 10:10:10")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss", timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE")
    private Date rowInsertDate;

    @ApiModelProperty(value = "Employee ID here")
    @Column(name = "ROW_UPDATE_BY")
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date As String", example = "31/05/2020 10:10:10")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss", timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE")
    private Date rowUpdateDate;


//    @Column(name = "GENDER")
//    private String gender;
//    @Column(name = "CONFIRM_DATE")
//    private Date confirmDate;
//    @Column(name = "EMAIL_ADDRESS")
//    private String emailAddress;
//    @Column(name = "PERSONAL_EMAIL_ADDRESS")
//    private String personalEmailAddress;
//    @Column(name = "MANAGER_EMPLOYEE_ID")
//    private String managerEmployeeId;
//    @Column(name = "FATHER_NAME")
//    private String fatherName;
//    @Column(name = "SPOUSE_NAME")
//    private String spouseName;
//    @Column(name = "IS_PHYSICALLY_CHALLENGED")
//    private Integer isPhysicallyChallenged;
//    @Column(name="IS_INTERNATIONAL_EMPLOYEE")
//    private Integer isInternationEmployee;
//    @Column(name = "BACKGROUND_CHECK_STATUS")
//    private String backgroundCheckStatus;
//    @Column(name = "BACKGROUND_VERIFICATION_COMPLETE_DATE")
//    private Date backgroundVerificationCompleteDate;
//    @Column(name = "AGENCY_NAME")
//   private String agencyName;
//    @Column(name = "BACKGROUND_CHECK_REMARKS")
//    private String backgroundCheckRemarks;
//    @Column(name = "EMERGENCY_CONTACT_NAME")
//    private String emergencyContactName;
//    @Column(name = "EMERGENCY_CONTACT_NUMBER")
//    private String emergencyContactNumber;
//    @Column(name = "BANK_ACCT_TYPE")
//    private String bankAcctType;
//    @Column(name = "BANK_NAME")
//    private String bankName;
//    @Column(name = "BANK_BRANCH")
//    private String bankBranch;
//    @Column(name = "PAYMENT_MODE")
//    private String paymentMode;
//    @Column(name = "FULL_NAME_AS_PER_BANK")
//    private String fullNameAsPerBank;
//    @Column(name = "IS_PF_ELLIGIBLE")
//    private String isPfElligible;
//    @Column(name = "PF_SCHEME")
//    private String pfScheme;
//    @Column(name = "PF_JOINING_DATE")
//    private Date pfJoiningDate;
//    @Column(name = "IS_ELLIGIBLE_EXCESS_EPF_CONTRIBUTION")
//    private Integer isElligibleExcessEpfContribution;
//    @Column(name = "LOCATION")
//    private String location;
//    @Column(name = "IS_EXISTING_PF")
//    private Integer isExistingPf;
//    @Column(name = "IS_ELLGIBLE_ESI")
//    private String isEsiElligible;
//    @Column(name = "FULL_NAME_AS_PER_AADHAAR")
//    private String fullNameAsPerAadhaar;
//    @Column(name = "MOBILE_NUMBER")
//    private String mobileNumber;
//    @Column(name = "COUNTRY_OF_ORIGIN")
//    private String countryOfOrigin;
//    @Column(name = "DEPARTMENT")
//    private String department;
//    @Column(name = "DESIGNATION")
//    private String designation;

    public char getCityType() {
        return cityType;
    }

    public void setCityType(char cityType) {
        this.cityType = cityType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

//    public void setGender(String gender) {
//        this.gender = gender;
//    }
//
//    public String getGender() {
//        return gender;
//    }
//
//    public void setConfirmDate(Date confirmDate) {
//        this.confirmDate = confirmDate;
//    }
//
//    public Date getConfirmDate() {
//        return confirmDate;
//    }
//
//    public void setEmailAddress(String emailAddress) {
//        this.emailAddress = emailAddress;
//    }
//
//    public String getEmailAddress() {
//        return emailAddress;
//    }
//
//    public void setPersonalEmailAddress(String personalEmailAddress) {
//        this.personalEmailAddress = personalEmailAddress;
//    }
//
//    public String getPersonalEmailAddress() {
//        return personalEmailAddress;
//    }
//
//    public void setManagerEmployeeId(String managerEmployeeId) {
//        this.managerEmployeeId = managerEmployeeId;
//    }
//
//    public String getManagerEmployeeId() {
//        return managerEmployeeId;
//    }
//
//    public void setFatherName(String fatherName) {
//        this.fatherName = fatherName;
//    }
//
//    public String getFatherName() {
//        return fatherName;
//    }
//
//    public void setSpouseName(String spouseName) {
//        this.spouseName = spouseName;
//    }
//
//    public String getSpouseName() {
//        return spouseName;
//    }
//
//    public void setIsPhysicallyChallenged(Integer isPhysicallyChallenged) {
//        this.isPhysicallyChallenged = isPhysicallyChallenged;
//    }
//
//    public Integer getIsPhysicallyChallenged() {
//        return isPhysicallyChallenged;
//    }
//
//    public void setIsInternationEmployee(Integer isInternationEmployee) {
//        this.isInternationEmployee = isInternationEmployee;
//    }
//
//    public Integer getIsInternationEmployee() {
//        return isInternationEmployee;
//    }
//
//    public void setBackgroundCheckStatus(String backgroundCheckStatus) {
//        this.backgroundCheckStatus = backgroundCheckStatus;
//    }
//
//    public String getBackgroundCheckStatus() {
//        return backgroundCheckStatus;
//    }
//
//    public void setBackgroundVerificationCompleteDate(Date backgroundVerificationCompleteDate) {
//        this.backgroundVerificationCompleteDate = backgroundVerificationCompleteDate;
//    }
//
//    public Date getBackgroundVerificationCompleteDate() {
//        return backgroundVerificationCompleteDate;
//    }
//
//    public void setAgencyName(String agencyName) {
//        this.agencyName = agencyName;
//    }
//
//    public String getAgencyName() {
//        return agencyName;
//    }
//
//    public void setBackgroundCheckRemarks(String backgroundCheckRemarks) {
//        this.backgroundCheckRemarks = backgroundCheckRemarks;
//    }
//
//    public String getBackgroundCheckRemarks() {
//        return backgroundCheckRemarks;
//    }
//
//    public void setEmergencyContactName(String emergencyContactName) {
//        this.emergencyContactName = emergencyContactName;
//    }
//
//    public String getEmergencyContactName() {
//        return emergencyContactName;
//    }
//
//    public void setEmergencyContactNumber(String emergencyContactNumber) {
//        this.emergencyContactNumber = emergencyContactNumber;
//    }
//
//    public String getEmergencyContactNumber() {
//        return emergencyContactNumber;
//    }
//
//    public void setBankAcctType(String bankAcctType) {
//        this.bankAcctType = bankAcctType;
//    }
//
//    public String getBankAcctType() {
//        return bankAcctType;
//    }
//
//    public void setBankName(String bankName) {
//        this.bankName = bankName;
//    }
//
//    public String getBankName() {
//        return bankName;
//    }
//
//    public void setBankBranch(String bankBranch) {
//        this.bankBranch = bankBranch;
//    }
//
//    public String getBankBranch() {
//        return bankBranch;
//    }
//
//    public void setPaymentMode(String paymentMode) {
//        this.paymentMode = paymentMode;
//    }
//
//    public String getPaymentMode() {
//        return paymentMode;
//    }
//
//    public void setFullNameAsPerBank(String fullNameAsPerBank) {
//        this.fullNameAsPerBank = fullNameAsPerBank;
//    }
//
//    public String getFullNameAsPerBank() {
//        return fullNameAsPerBank;
//    }
//
//    public void setIsPfElligible(String isPfElligible) {
//        this.isPfElligible = isPfElligible;
//    }
//
//    public String getIsPfElligible() {
//        return isPfElligible;
//    }
//
//    public void setPfScheme(String pfScheme) {
//        this.pfScheme = pfScheme;
//    }
//
//    public String getPfScheme() {
//        return pfScheme;
//    }
//
//    public void setPfJoiningDate(Date pfJoiningDate) {
//        this.pfJoiningDate = pfJoiningDate;
//    }
//
//    public Date getPfJoiningDate() {
//        return pfJoiningDate;
//    }
//
//    public void setIsElligibleExcessEpfContribution(Integer isElligibleExcessEpfContribution) {
//        this.isElligibleExcessEpfContribution = isElligibleExcessEpfContribution;
//    }
//
//    public Integer getIsElligibleExcessEpfContribution() {
//        return isElligibleExcessEpfContribution;
//    }
//
//    public void setLocation(String location) {
//        this.location = location;
//    }
//
//    public String getLocation() {
//        return location;
//    }
//
//    public void setIsExistingPf(Integer isExistingPf) {
//        this.isExistingPf = isExistingPf;
//    }
//
//    public Integer getIsExistingPf() {
//        return isExistingPf;
//    }
//
//    public void setIsEsiElligible(String isEsiElligible) {
//        this.isEsiElligible = isEsiElligible;
//    }
//
//    public String getIsEsiElligible() {
//        return isEsiElligible;
//    }
//
//    public void setFullNameAsPerAadhaar(String fullNameAsPerAadhaar) {
//        this.fullNameAsPerAadhaar = fullNameAsPerAadhaar;
//    }
//
//    public String getFullNameAsPerAadhaar() {
//        return fullNameAsPerAadhaar;
//    }
//
//    public void setMobileNumber(String mobileNumber) {
//        this.mobileNumber = mobileNumber;
//    }
//
//    public String getMobileNumber() {
//        return mobileNumber;
//    }
//
//    public void setCountryOfOrigin(String countryOfOrigin) {
//        this.countryOfOrigin = countryOfOrigin;
//    }
//
//    public String getCountryOfOrigin() {
//        return countryOfOrigin;
//    }
//
//    public void setDepartment(String department) {
//        this.department = department;
//    }
//
//    public String getDepartment() {
//        return department;
//    }
//
//    public void setDesignation(String designation) {
//        this.designation = designation;
//    }
//
//    public String getDesignation() {
//        return designation;
//    }
}
