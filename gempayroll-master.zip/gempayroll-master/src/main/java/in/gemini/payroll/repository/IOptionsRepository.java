package in.gemini.payroll.repository;

import in.gemini.payroll.entity.PayrollOptions;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IOptionsRepository extends JpaRepository<PayrollOptions,Integer> {
    List<PayrollOptions> findByoptionKey(String key);
}
