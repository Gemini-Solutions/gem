package in.gemini.payroll.repository;

import in.gemini.payroll.entity.EmployeeInvestmentDeclaration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface EmpInvestDeclareRepo extends JpaRepository<EmployeeInvestmentDeclaration,Long> {

    List<EmployeeInvestmentDeclaration> findByEmployeeId(Integer employeeId);
    
    Optional<EmployeeInvestmentDeclaration> findByInvestmentViaId(Long investmentViaId);
}
