package in.gemini.payroll.repository;

import in.gemini.payroll.entity.DeductionsXref;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeductionsXrefRepository extends JpaRepository<DeductionsXref, String> {
}
