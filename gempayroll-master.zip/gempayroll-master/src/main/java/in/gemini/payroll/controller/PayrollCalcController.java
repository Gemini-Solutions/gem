package in.gemini.payroll.controller;

import in.gemini.payroll.Response.GrossAndCTCPlaceHolder;
import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.CtcStructure;
import in.gemini.payroll.services.PayrollService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payrollCalc")
public class PayrollCalcController {

    @Autowired
    private PayrollService payrollService;

    @GetMapping("getAllPayroll")
    @ApiOperation(value = "Get payroll calc for all employees")
    public ResponseClass getPayrollCalc()
    {
        return new ResponseClass(payrollService.getPayrollCalc(),
                "SUCCESS", HttpStatus.OK);
    }


    @GetMapping("getAllPayroll/{employeeId}")
    @ApiOperation(value = "Get payroll calc for all employees")
    public ResponseClass getPayrollCalcByEmpId(@PathVariable Integer employeeId)
    {
        return new ResponseClass(payrollService.getPayrollCalcByEmpId(employeeId),
                "SUCCESS", HttpStatus.OK);
    }


    @ApiOperation(value = "API to Gross and CTC before tax", notes="Calculates CTC and Gross before tax")
    @PostMapping("/getGrossAndCTCbeforeTax")
    public ResponseClass getGrossAndCTCBeforeTax(@RequestBody List<GrossAndCTCPlaceHolder> grossAndCTCPlaceHolder){
        try {
             return new ResponseClass(payrollService.calcGrossAndCTCBeforeTax(grossAndCTCPlaceHolder)
                     , "SUCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
