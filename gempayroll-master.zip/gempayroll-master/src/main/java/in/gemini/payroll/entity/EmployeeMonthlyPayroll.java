package in.gemini.payroll.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;

import javax.persistence.*;
import java.util.Date;

import static javax.persistence.GenerationType.SEQUENCE;


@Entity
@Table(name="EMPLOYEE_MONTHLY_PAYROLL",schema = "payroll")
public class EmployeeMonthlyPayroll {

    @Id
    @Column(name="EMPLOYEE_MONTHLY_PAYROLL_ID")
    @SequenceGenerator(name = "seq", sequenceName = "payroll.employee_monthly_payroll_employee_monthly_payroll_id_seq", allocationSize = 1)
    @GeneratedValue(strategy = SEQUENCE, generator = "seq")
    private Integer monthlyPayslipId;

    @Column(name = "PAYROLL_YEAR")
    private Integer payslipYear;

    @Column(name = "EMPLOYEE_ID")
    private Integer employeeId;

    @Column(name = "COMPONENT")
    private String payslipComponent;

    @Column(name = "AMOUNT")
    private Double componentAmount;

    public EmployeeMonthlyPayroll() {
    }

    @Column(name = "PAYROLL_MONTH")
    private Integer payslipMonth;

    @ApiParam(value="User name who is trying to insert data", required = true)
    @Column(name="ROW_INSERT_BY")
    private String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name="ROW_INSERT_DATE")
    private Date rowInsertDate;

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    @ApiParam(value="User name who is trying to update data")
    @Column(name="ROW_UPDATE_BY")
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name="ROW_UPDATE_DATE")
    private Date rowUpdateDate;

    public EmployeeMonthlyPayroll(Integer monthlyPayslipId, Integer payslipYear, Integer employeeId, String payslipComponent, Double componentAmount, Integer payslipMonth, String rowInsertBy, Date rowInsertDate, String rowUpdateBy, Date rowUpdateDate) {
        this.monthlyPayslipId = monthlyPayslipId;
        this.payslipYear = payslipYear;
        this.employeeId = employeeId;
        this.payslipComponent = payslipComponent;
        this.componentAmount = componentAmount;
        this.payslipMonth = payslipMonth;
        this.rowInsertBy = rowInsertBy;
        this.rowInsertDate = rowInsertDate;
        this.rowUpdateBy = rowUpdateBy;
        this.rowUpdateDate = rowUpdateDate;
    }

    public Integer getMonthlyPayslipId() {
        return monthlyPayslipId;
    }

    public void setMonthlyPayslipId(Integer monthlyPayslipId) {
        this.monthlyPayslipId = monthlyPayslipId;
    }

    public Integer getPayslipMonth() {
        return payslipMonth;
    }

    public void setPayslipMonth(Integer payslipMonth) {
        this.payslipMonth = payslipMonth;
    }

    public Integer getPayslipYear() {
        return payslipYear;
    }

    public void setPayslipYear(Integer payslipYear) {
        this.payslipYear = payslipYear;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getPayslipComponent() {
        return payslipComponent;
    }

    public void setPayslipComponent(String payslipComponent) {
        this.payslipComponent = payslipComponent;
    }

    public Double getComponentAmount() {
        return componentAmount;
    }

    public void setComponentAmount(Double componentAmount) {
        this.componentAmount = componentAmount;
    }

}