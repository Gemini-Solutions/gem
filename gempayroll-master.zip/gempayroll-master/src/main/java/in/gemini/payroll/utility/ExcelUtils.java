package in.gemini.payroll.utility;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class ExcelUtils {

    private static final Logger log = LoggerFactory.getLogger(ExcelUtils.class);

    // Utility classes should not have public constructors. Hence, declare private default constructor
    private ExcelUtils() {
    }

    public static boolean checkIfRowIsEmpty(Row row) {
    if (row == null) {
        return true;
    }
    if (row.getLastCellNum() <= 0) {
        return true;
    }
    for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
        Cell cell = row.getCell(cellNum);
        if (cell != null && cell.getCellType() != CellType.BLANK && StringUtils.isNotBlank(cell.toString())) {
            return false;
        }
    }
    return true;
}

    /**
     * @param headerRow     row that contains the headers of an Excel file that was uploaded
     * @param columnNameMap A Map that is read from properties file that contains the integer key, column name. Map key defines the order of that column
     */
    public static void checkIfValidExcelUpload(Row headerRow, Map<Integer, String> columnNameMap) throws Exception {

        DataFormatter formatter = new DataFormatter(); // Returns value as string regardless of cell type.

        if (checkIfRowIsEmpty(headerRow)) {
            throw new Exception("Empty excel detected");
        }

        for (int cellCount = 0; cellCount < headerRow.getPhysicalNumberOfCells(); cellCount++) {
            if (!StringUtils.equalsIgnoreCase(columnNameMap.get(cellCount), formatter.formatCellValue(headerRow.getCell(cellCount)))) {
                log.error("index: {}, column Name from properties: {}", cellCount, columnNameMap.get(cellCount));
                 throw new Exception("provided excel column :  " + headerRow.getCell(cellCount) +
                         ", expected column name from properties: " + columnNameMap.get(cellCount));
            }
        }

    }
}
