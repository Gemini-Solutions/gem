package in.gemini.payroll.services;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import in.gemini.payroll.controller.CtcController;
import in.gemini.payroll.entity.CtcStructure;
import in.gemini.payroll.repository.CtcRepository;

@Service
public class CtcService {

	@Autowired
	private CtcRepository ctcRepository;
	
	private static final Logger log = LoggerFactory.getLogger(CtcController.class);
	
	public CtcStructure addCtcComponentService(CtcStructure ctcStructure) throws Exception {
		CtcStructure response =  new CtcStructure();
		log.info("Inside add ctc component srevice - " + ctcStructure.toString());
//		Optional<CtcStructure> ctc = ctcRepository.findById(ctcStructure.getCtcComponent());
//		if(ctc.isPresent()) {
//			throw new Exception(ctcStructure.getCtcComponent() + " component already exist");
//		}
		ctcStructure.setRowInsertDate(new Timestamp(System.currentTimeMillis()));
		ctcStructure.setRowUpdateDate(new Timestamp(System.currentTimeMillis()));
		try {
			response = ctcRepository.save(ctcStructure);

		}catch (DataAccessException dex)
		{
			throw new Exception(dex.getLocalizedMessage());
		}
		return response;
 	}
	
	public List<CtcStructure> getAllCtcComponentService() throws Exception {
		List<CtcStructure> ctcList = null;
		log.info("Inside get all ctc component service");
		ctcList = (List<CtcStructure>) (ctcRepository.findAll());
		if(ctcList==null || ctcList.isEmpty()) {
			throw new Exception("data not found");
		}
		return ctcList;
	}
	
	public CtcStructure getCtcComponentService(String ctcComponent) throws Exception {
		log.info("Inside get ctc component service - " + ctcComponent);
		Optional<CtcStructure> ctc = ctcRepository.findById(ctcComponent);
		if(!ctc.isPresent()) {
			throw new Exception(ctcComponent + " is not present");
		}
		return ctc.get();
	}
	
	public void deleteCtcComponentService(String ctcComponent) throws Exception {
		log.info("Inside delete ctc component service - " + ctcComponent);
		Optional<CtcStructure> ctcStructure = ctcRepository.findById(ctcComponent);
		if(!ctcStructure.isPresent()) {
			throw new Exception(ctcComponent + " does not exist");
		}
		ctcRepository.deleteById(ctcComponent);
	}
	
	public CtcStructure updateCtcComponentService(CtcStructure ctcStructure) throws Exception {
		CtcStructure response =  new CtcStructure();
		log.info("Inside update ctc component service - " + ctcStructure.toString());
		Optional<CtcStructure> ctc = ctcRepository.findById(ctcStructure.getCtcComponent());
		if(!ctc.isPresent()) {
			throw new Exception(ctcStructure.getCtcComponent() + " component does not exist");
		}
		ctcStructure.setRowUpdateDate(new Timestamp(System.currentTimeMillis()));
		response = ctcRepository.save(ctcStructure);
		return response;
 	}
}
