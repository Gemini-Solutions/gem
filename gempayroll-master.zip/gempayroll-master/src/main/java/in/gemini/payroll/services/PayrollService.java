package in.gemini.payroll.services;

import in.gemini.payroll.Response.GrossAndCTCPlaceHolder;
import in.gemini.payroll.entity.PayrollCalc;
import in.gemini.payroll.repository.IPayrollCalc;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PayrollService {

    @Autowired
    private IPayrollCalc iPayrollCalc;
    @Value("${payroll.grossComponent}")
    private String grossComponent;
    @Value("${payroll.ctcComponent}")
    private String ctcComponent;
    @Value("${payroll.flexiComponent}")
    private String flexiComponent;

    public List<PayrollCalc> getPayrollCalc()
    {
        List<PayrollCalc> payrollCalcList = null;
        payrollCalcList = (List<PayrollCalc>) (iPayrollCalc.findAll());
        return payrollCalcList;
    }

    public List<PayrollCalc> getPayrollCalcByEmpId(Integer employeeID)
    {
        List<PayrollCalc> payrollCalcList = null;
        payrollCalcList = (List<PayrollCalc>) (iPayrollCalc.findByemployeeId(employeeID));
        return payrollCalcList;
    }


    /*
    The function is considered to change very rare, so hardcoding,
    even if DB called the information has to be stored somewhere , hence storing here for now
    but will change in future, make it more generic than hard coding
     */

    public List<GrossAndCTCPlaceHolder> calcGrossAndCTCBeforeTax(List<GrossAndCTCPlaceHolder> grossAndCTCPlaceHolder)
    {
        List<GrossAndCTCPlaceHolder> grossAndCTCPlaceHolderList = new ArrayList<>();
        Map<String,Integer> map = new HashMap<>();
        Integer grossSalary=0,ctc=0,flexi=0;
        for(GrossAndCTCPlaceHolder grossAndCTCPlaceHolder1 : grossAndCTCPlaceHolder)
        {
            if(grossComponent.contains(grossAndCTCPlaceHolder1.getCtcComponent()))
                grossSalary += grossAndCTCPlaceHolder1.getAmount();

            if(flexiComponent.contains(grossAndCTCPlaceHolder1.getCtcComponent()))
                flexi += grossAndCTCPlaceHolder1.getAmount();

            ctc+=grossAndCTCPlaceHolder1.getAmount();
        }

        grossAndCTCPlaceHolderList.add(new GrossAndCTCPlaceHolder("GROSS_SALARY",grossSalary));
        grossAndCTCPlaceHolderList.add(new GrossAndCTCPlaceHolder("CTC",ctc));
        grossAndCTCPlaceHolderList.add(new GrossAndCTCPlaceHolder("TOTAL_FLEXI_BASKET",flexi));
        return grossAndCTCPlaceHolderList;
    }
}
