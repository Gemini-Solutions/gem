package in.gemini.payroll.services;

import in.gemini.payroll.entity.DeductionsXref;
import in.gemini.payroll.entity.EmployeeDeductions;
import in.gemini.payroll.repository.DeductionsXrefRepository;
import in.gemini.payroll.repository.EmployeeDeductionsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeDeductionService {

    @Autowired
    private EmployeeDeductionsRepository employeeDeductionsRepository;

    @Autowired
    private DeductionsXrefRepository deductionsXrefRepository;

    private static final Logger log = LoggerFactory.getLogger(EmployeeDeductionService.class);

    public EmployeeDeductions createEmployeeDeductions(EmployeeDeductions employeeDeductions) throws Exception {
        log.info("Service createEmployeeDeductions {}", employeeDeductions);
//        Optional<EmployeeDeductions> empDed = employeeDeductionsRepository.findByEmployeeId(employeeDeductions.getEmployeeId());
        // Check if an employee deduction entry already exists. No insertion if it already exists.
        Optional<EmployeeDeductions> empDed = employeeDeductionsRepository.findByEmployeeIdAndDeduction(employeeDeductions.getEmployeeId(),
                employeeDeductions.getDeduction());
        if (empDed.isPresent()) {
            log.error("Service createEmployeeDeductions error deduction {} already exists", empDed);
            throw new Exception("Deduction component for Employee Id " + empDed.get().getEmployeeId() + " with deduction "
                    + empDed.get().getDeduction() + " +  already exists");

        }
        // employee deduction will be newly created in employee deductions table. Check if amount entered for employee deductions
        // does not exceed deductions Xref amount.
        Optional<DeductionsXref> deductionsXref = deductionsXrefRepository.findById(employeeDeductions.getDeduction());

        if (!deductionsXref.isPresent()) {
            log.error("Deduction {} entered by {} not found in deduction xref", employeeDeductions.getDeduction(), employeeDeductions.getRowInsertBy());
            throw new Exception("Deduction " + employeeDeductions.getDeduction() + " not found in deductions Xref");
        }

        if (deductionsXref.get().getDeductionLimit() >= employeeDeductions.getAmount() && deductionsXref.get().getDeduction().equalsIgnoreCase(employeeDeductions.getDeduction())) {
            employeeDeductions.setRowInsertDate(new Date());
            employeeDeductions.setRowUpdateDate(new Date());
            employeeDeductions.setRowUpdateBy(employeeDeductions.getRowInsertBy());

            return employeeDeductionsRepository.save(employeeDeductions);

        } else {

            throw new Exception("Deduction limit of " + employeeDeductions.getDeduction() + " exceeded." + "Deduction limit " + deductionsXref.get().getDeductionLimit());

        }
//        empDed.ifPresent(val -> {} );

    }

    public List<EmployeeDeductions> getAllEmployeesDeductions() throws Exception {
        log.info("Service getAllEmployeesDeductions");
        List<EmployeeDeductions> data = employeeDeductionsRepository.findAll();
        if (data.isEmpty()) {
            log.error("Service getAllEmployeesDeductions No employees deduction data found");
            throw new Exception(" No data found in Employees Deduction");
        }

        return data;

    }

    public EmployeeDeductions getEmpDeductionByEmpIdAndDeduction(Integer employeeId, String deduction) throws Exception {
        log.info("Service getEmpDeductionByEmpIdAndDeduction empId {}  and deduction {}", employeeId, deduction);
        Optional<EmployeeDeductions> empDed = employeeDeductionsRepository.findByEmployeeIdAndDeduction(employeeId, deduction);

        if (!empDed.isPresent()) {
            log.error("Service getEmpDeductionByEmpIdAndDeduction no data found for Employee ID {} with Deduction {}", employeeId, deduction);
            throw new Exception(" No Employee Deduction data found for Employee ID " + employeeId + " with Deduction  " + deduction);
        }
        return empDed.get();
    }

    public EmployeeDeductions updateEmployeeDeduction(EmployeeDeductions employeeDeductions) throws Exception {
        log.info("Service updateEmployeeDeductions {}", employeeDeductions);
//        Optional<EmployeeDeductions> empDed = employeeDeductionsRepository.findByEmployeeId(employeeDeductions.getEmployeeId());
        Optional<EmployeeDeductions> empDed = employeeDeductionsRepository.findByEmployeeIdAndDeduction(employeeDeductions.getEmployeeId(),
                employeeDeductions.getDeduction());

        if (!empDed.isPresent()) {
            throw new Exception("Service updateEmployeeDeductions Deduction component for Employee Id " + employeeDeductions.getEmployeeId() + " with deduction "
                    + employeeDeductions.getDeduction() + " +  does not exist");
        }

        // employee deduction will be updated in employee deductions table, so first check if amount entered for employee deductions
        // does not exceed deductions Xref amount for the same deduction.
        Optional<DeductionsXref> deductionsXref = deductionsXrefRepository.findById(employeeDeductions.getDeduction());

        if (!deductionsXref.isPresent()) {
            log.error("Deduction {} entered by {} not found in deduction xref", employeeDeductions.getDeduction(), employeeDeductions.getRowUpdateBy());

            throw new Exception("Deduction " + employeeDeductions.getDeduction() + " not found in deduction xref");
        }

        if (deductionsXref.get().getDeductionLimit() >= employeeDeductions.getAmount() && deductionsXref.get().getDeduction().equalsIgnoreCase(employeeDeductions.getDeduction())) {

            empDed.get().setDeduction(employeeDeductions.getDeduction());
            empDed.get().setAmount(employeeDeductions.getAmount());
            empDed.get().setStatus(employeeDeductions.getStatus());
            empDed.get().setFiscal(employeeDeductions.getFiscal());
            empDed.get().setRowUpdateBy(employeeDeductions.getRowUpdateBy());
            empDed.get().setRowUpdateDate(new Date());

//        empDed.ifPresent(val -> {} );
            return employeeDeductionsRepository.save(empDed.get());
        } else {
            throw new Exception("Deduction limit of " + employeeDeductions.getDeduction() +
                    " exceeded. " + "Deduction limit " + deductionsXref.get().getDeductionLimit());

        }
//        return null;
    }

    @Transactional
    public void deleteEmployeeDeductionByEmployeeIdAndDeduction(Integer employeeId, String deduction) throws Exception {
        log.info("Service deleteEmployeeDeduction having employeeId {} and deduction {}", employeeId, deduction);

        // delete from record if employee id exists
        if (employeeDeductionsRepository.existsByEmployeeIdAndDeduction(employeeId, deduction)) {

            log.info("Service deleteEmployeeDeductionByEmployeeIdAndDeduction Employee id {} and deduction {} found | Deleting", employeeId, deduction);
            employeeDeductionsRepository.deleteByEmployeeIdAndDeduction(employeeId, deduction);
            log.info("Service deleteEmployeeDeductionByEmployeeIdAndDeduction with employeeId {} and deduction {} delete success", employeeId, deduction);

        } else {
            log.error("Service deleteEmployeeDeductionByEmployeeIdAndDeduction Employee Id {} with deduction {} does not exist", employeeId, deduction);
            throw new Exception("Employee Id " + employeeId + " with deduction " + deduction + " does not exist");
        }
    }
}
