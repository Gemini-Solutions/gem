package in.gemini.payroll.controller;

import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.dto.EmployeeInvestmentCalcDTO;
import in.gemini.payroll.entity.EmployeeInvestmentCalc;
import in.gemini.payroll.services.EmployeeInvestmentCalcService;
import io.swagger.v3.oas.annotations.Operation;
//import io.swagger.v3.oas.annotations.media.Content;
//import io.swagger.v3.oas.annotations.media.ExampleObject;
//import io.swagger.v3.oas.annotations.media.Schema;
//import io.swagger.v3.oas.annotations.responses.ApiResponse;
//import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/employee-investment")
public class EmployeeInvestmentCalcController {

    @Autowired
    private EmployeeInvestmentCalcService employeeInvestmentCalcService;

    private static final Logger log = LoggerFactory.getLogger(EmployeeInvestmentCalcController.class);

    @PostMapping("/addEmpInvestment")
    @Operation(summary = "add investment",description = "add employee investment ",operationId = "addEmpInvestment")
    public ResponseClass addEmployeeInvestment(@RequestBody EmployeeInvestmentCalc employeeInvestmentCalc){
        log.info("REST add employee investment {}",employeeInvestmentCalc);
        try{
//            EmployeeInvestmentCalcDTO response = employeeInvestmentCalcService.addEmployeeInvestment(employeeInvestmentCalc);
//            log.info("REST add employee investment response {}",response);

//            return new ResponseClass(response,"SUCCESS", HttpStatus.OK);
            return new ResponseClass(employeeInvestmentCalcService.addEmployeeInvestment(employeeInvestmentCalc) ,"SUCCESS", HttpStatus.OK);
        } catch (Exception e){
            e.printStackTrace();
            log.error("REST addEmployeeInvestmentError {}",e.getMessage());
            return new ResponseClass(e.getMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
