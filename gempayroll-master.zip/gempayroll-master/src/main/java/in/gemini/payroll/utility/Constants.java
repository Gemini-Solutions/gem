package in.gemini.payroll.utility;

import java.util.*;

public class Constants {

    /*
    * contains salary components only that are part of an employee's offer letter or appraisal annexure.
    * Does not contain tax saving or benefits components like PAYTM etc.
    */
    public static final  Map<Integer, String> salaryComponentsForExcel = new HashMap<>();

    static {
        salaryComponentsForExcel.put(43, "BASIC_PAY");
        salaryComponentsForExcel.put(44, "HRA");
        salaryComponentsForExcel.put(45, "STANDARD_ALLOWANCE");
        salaryComponentsForExcel.put(46, "SPECIAL_ALLOWANCE");
        salaryComponentsForExcel.put(47, "LOYALTY_BONUS");
        salaryComponentsForExcel.put(48, "GRATUITY");
        salaryComponentsForExcel.put(49, "WELFARE_CONTRIBUTION");
    }

    public static void main(String args[])
    {
        List<String> list1 = Arrays.asList("jhg","gfgfgt","fcdfd","efewd","qwe");

        System.out.println(list1.containsAll(Arrays.asList("jhg","fcdfd")));
    }
}
