package in.gemini.payroll.services;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import in.gemini.payroll.entity.EmployeeCtc;
import in.gemini.payroll.utility.Constants;
import in.gemini.payroll.utility.ExcelUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import in.gemini.payroll.entity.EmployeeDetails;
import in.gemini.payroll.repository.EmployeeDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeDetailsRepository employeeDetailsRepository;

    @Autowired
    private EmployeeCtcService employeeCtcService;


    @Value("${payroll.employeedetails.excelcolumns}")
    private String[] bulkImportExcelColumns;

    private static final Logger log = LoggerFactory.getLogger(EmployeeService.class);


    /**
     * Reads the columns list in order that are provided by properties file to
     * return a map of column order starting from zero as key and column name as value
     *
     * @return a map of (integer column order starting from zero as key (0,1,2,... array size)) and ("column name") as value.
     */
    private Map<Integer, String> getBulkImportExcelColumns() {

        List<String> strList = Arrays.asList(bulkImportExcelColumns);

        return IntStream.range(0, strList.size())
                .boxed()
                .collect(Collectors.toMap(Function.identity(), strList::get));
    }

    public EmployeeDetails addNewEmployee(EmployeeDetails employeeDetails) throws Exception {
        EmployeeDetails response;
        // convert DTO entity
        log.info("Service addOrUpdateNewEmployee add new with employeeId {} ", employeeDetails.getEmployeeId());

//        // Check if employee already exists
//        Optional<EmployeeDetails> emp = employeeDetailsRepository.findById(employeeDetails.getEmployeeId());
//        if (emp.isPresent()) {
//            throw new Exception(employeeDetails.getEmployeeId() + " Employee already exists.");
//        }

        employeeDetails.setRowInsertDate(new Date());
        employeeDetails.setRowUpdateDate(new Date());
        employeeDetails.setRowUpdateBy(employeeDetails.getRowInsertBy());

        response = employeeDetailsRepository.save(employeeDetails);
        return response;
    }

    public List<EmployeeDetails> getAllEmployees() throws Exception {

        ArrayList<EmployeeDetails> data;

        log.info("Service getAllEmployees");
        data = new ArrayList<>(employeeDetailsRepository.findAll());

        if (data.isEmpty()) {
            log.error("No data found in employee");
            throw new Exception(" No data found in Employee");
        }

        return data;
    }

    public EmployeeDetails getEmployeeById(Integer id) throws Exception {

        log.info("Service getEmployeeById id {}", id);
        Optional<EmployeeDetails> optional = employeeDetailsRepository.findById(id);

        // if data is not found
        if (!optional.isPresent()) {
            log.error("No data found in employee");
            throw new Exception("Employee id " + id + " does not exist.");
        }
        return optional.get();
    }

    public void deleteEmployeeById(Integer id) throws Exception {

        log.info("Service deleteEmployeeById having id {}", id);

        // delete from record if employee id exists
        if (employeeDetailsRepository.existsById(id)) {

            log.info("Employee id {} found | Deleting", id);
            employeeDetailsRepository.deleteById(id);
            log.info("Employee of id {} delete success", id);

        } else {
            log.error("Service deleteEmployeeById Employee Id {} does not exist", id);
            throw new Exception("Employee Id " + id + " does not exist");
        }
    }

    public EmployeeDetails updateEmployee(EmployeeDetails employeeDetails) throws Exception {
         EmployeeDetails response;
        // convert DTO entity
        log.info("Service addOrUpdateNewEmployee with employeeId {} ", employeeDetails.getEmployeeId());

        // Check if employee already exists
        Optional<EmployeeDetails> emp = employeeDetailsRepository.findById(employeeDetails.getEmployeeId());
        if (!emp.isPresent()) {
            throw new Exception(employeeDetails.getEmployeeId() + " Employee does not exist.");
        }

        employeeDetails.setRowUpdateDate(new Date());
        // insert into db
        response = employeeDetailsRepository.save(employeeDetails);

        return response;
    }

    @Transactional
    public void parseBulkImportEmployeeCSV(InputStream inputStream) throws Exception {
//        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MON-yyyy");
        List<String[]> valueList;
        CSVReader csvReader = new CSVReaderBuilder(new InputStreamReader(inputStream)).withSkipLines(1).build();
        valueList = csvReader.readAll();
//        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        bulkImportEmployee(valueList);
    }


    @Transactional
    public void parseBulkImportEmployeeExcel(InputStream inputStream) throws Exception {
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        //How can we know there is only ne sheet
        XSSFSheet sheet = workbook.getSheetAt(0);


//        Iterator<Row> rowIterator = sheet.iterator();
        DataFormatter formatter = new DataFormatter();

//        int cellCount = -1;

        List<String[]> valueList = new ArrayList<>();

        // Nov 30 2021 check bad file upload. If yes, throw exception.
        // Check for order of columns and value of columns should be exact. Hard coding here.
        ExcelUtils.checkIfValidExcelUpload(sheet.getRow(0), getBulkImportExcelColumns());


            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i); // iterate to next row directly, skipping first header row.

                if (ExcelUtils.checkIfRowIsEmpty(row)) {
                    break;
                }
                String[] valueRow = new String[sheet.getRow(0).getPhysicalNumberOfCells()];

                for (int cellCount = 0; cellCount < sheet.getRow(0).getPhysicalNumberOfCells(); cellCount++) {
                    System.out.println(row.getCell(cellCount));
                    valueRow[cellCount] = formatter.formatCellValue(row.getCell(cellCount));
                }


//            while (cellIterator.hasNext()) {
//                ++cellCount;
//                valueRow[cellCount] = row.getCell(cellCount).getStringCellValue();
//            }


                valueList.add(valueRow);

            }

            // finally all parsed excel rows to be inserted
            bulkImportEmployee(valueList);

    }
//    private void  bulkImportEmployee(List<String[]> valueList) throws Exception {
//
//        List<EmployeeCtc> employeeCtcList = new ArrayList<>();
//
////        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
//        /*
//         * employee id (mandatory)
//         * Name field combined called as Name (mandatory) {first name last name} TODO middle name field missing
//         * date of joining (dd-MMM-yyyy)  (mandatory)
//         * date of birth (dd-MMM-yyyy)
//         * Employee Status
//         * Gender
//         * Confirm Date
//         * Email Address (work email)
//         * Personal Email Address
//         * pan number
//         * Manager Employee Number
//         * Father's Name
//         * Spouse Name
//         * isPhysicallyChallenged (1 or 0)
//         * isInternationalEmployee (1 or 0)
//         * Background check status ['Verified', 'Pending','Initiated', 'Rejected']
//         * Background Verification completed on
//         * Agency name
//         * Background check Remarks
//         * Emergency Contact Name
//         * Emergency Contact Number
//         * Bank Account Number
//         * IFSC
//         * Bank Account Type
//         * Bank Name
//         * Bank Branch
//         * Salary Payment Mode
//         * Name as per Bank Records
//         * isEligibleForPF
//         * PfNo
//         * PF_Scheme
//         * PF Joining Date (dd-MON-yyyy)
//         * isEligibleForExcessEPF_Contribution (1 or 0)
//         * isExistingMemberOfPF (1 or 0)
//         * isEligibleForESI (yes or no)
//         * Name as per Aadhaar
//         * Aadhaar Number
//         * Universal Account Number (UAN) (needs to be of type number)
//         * Mobile Number
//         * Country Of Origin
//         * Department
//         * Designation
//         * Location (mandatory)
//         * Basic
//         * House Rent Allowance
//         * Standard Deduction
//         * Special Allowance
//         * Loyalty Bonus
//         * Gratuity
//         * Welfare Contribution
//         */
//
//        for (String[] value : valueList) {
//            int colNumber = -1;
//            EmployeeDetails employeeDetails = new EmployeeDetails();
//
//            colNumber++; // 0
//            if (StringUtils.isBlank(value[colNumber])) { // checked at index 0
//                throw new Exception("Employee ID is mandatory");
//            }
////            employeeDetails.setEmployeeId(Integer.parseInt(value[colNumber++])); // No effect as EmployeeID is serial // 0
//            colNumber++; // TODO employee ID is entered via serial in database keeping it as null for now.
//
//            if (StringUtils.isBlank(value[colNumber])) {  // checked at index 1
//                throw new Exception("Name field mandatory.");
//            }
//            // split fullName in excel based on space character as firstName and lastName.
//            String[] fullName = value[colNumber++].split("\\s"); // 1
//
//            long countOfName = fullName.length;
//            // TODO still unsure how to split name string to separate first name and last name. eg: Rasipuram Krishnaswami Iyer Narayanaswami.
//            //  What is first name and last name here? For now considering last name as Narayanaswami as of now.
//            employeeDetails.setFirstName(Arrays.stream(fullName).limit(countOfName-1).collect(Collectors.joining(" ")));
//            employeeDetails.setLastName(Arrays.stream(fullName).skip(countOfName-1).collect(Collectors.joining(" ")));
//            // TODO still unsure how to split name string to separate first name and last name. eg: Rasipuram Krishnaswami Iyer Narayanaswami.
//            employeeDetails.setDateOfJoining(new Date(value[colNumber++])); // need to change to localDate type // 2
//            employeeDetails.setDateOfBirth(new Date(value[colNumber++]));   // need to change to localDate type // 3
//
//            employeeDetails.setStatus(value[colNumber++]); // 4
////            employeeDetails.setGender(value[colNumber++]); // 5
////            employeeDetails.setConfirmDate(new Date(value[colNumber++]));  // 6
////            employeeDetails.setEmailAddress(value[colNumber++]); // 7
////            employeeDetails.setPersonalEmailAddress(value[colNumber++]); // 8
////            employeeDetails.setPan(value[colNumber++]); // 9
////            employeeDetails.setManagerEmployeeId(value[colNumber++]); // 10
////            employeeDetails.setFatherName(value[colNumber++]); // 11
////            employeeDetails.setSpouseName(value[colNumber++]); // 12
////            employeeDetails.setIsPhysicallyChallenged(Integer.parseInt(value[colNumber++]) == 1 ? 1 : 0 ); // 13
////            employeeDetails.setIsInternationEmployee(Integer.parseInt(value[colNumber++]) == 1 ? 1 : 0 ); // 14
////            employeeDetails.setBackgroundCheckStatus(value[colNumber++]); // 15
////            employeeDetails.setBackgroundVerificationCompleteDate(new Date(value[colNumber++])); // 16
//////            employeeDetails.setAgencyName(value[colNumber++]); // 17
////            employeeDetails.setBackgroundCheckRemarks(value[colNumber++]); // 18
////            employeeDetails.setEmergencyContactName(value[colNumber++]); // 19
////            employeeDetails.setEmergencyContactNumber(value[colNumber++]); // 20
////            // TODO add details in employee details or employeeCTC?
////            //  CTC will only contain salary info, I guess remaining details about bank,IFSC, account type, Payment method will be employee details?
////            employeeDetails.setBankAcctNo(value[colNumber++]); // 21
////            employeeDetails.setBankIFSC(value[colNumber++]); // 22
////            employeeDetails.setBankAcctType(value[colNumber++]); // 23
////            employeeDetails.setBankName(value[colNumber++]); // 24
////            employeeDetails.setBankBranch(value[colNumber++]); // 25
////            employeeDetails.setPaymentMode(value[colNumber++]); // 26
////            employeeDetails.setFullNameAsPerBank(value[colNumber++]);// 27
////            // TODO have employee PF eligibility check field in employee Details?
////            employeeDetails.setIsPfElligible(value[colNumber++]); // 28
////            employeeDetails.setPfNo(employeeDetails.getIsPfElligible().equalsIgnoreCase("yes") ? value[colNumber++] : "no"); // 29
////            employeeDetails.setPfScheme(value[colNumber++]); // 30
////            employeeDetails.setPfJoiningDate(new Date(value[colNumber++])); // 31
////            employeeDetails.setIsElligibleExcessEpfContribution(Integer.parseInt(value[colNumber++]) == 1 ? 1 : 0); // 32
////            employeeDetails.setIsExistingPf(Integer.parseInt(value[colNumber++]) == 1 ? 1 : 0); // 33
////            employeeDetails.setIsEsiElligible(value[colNumber++]); // 34
////            employeeDetails.setFullNameAsPerAadhaar(value[colNumber++]); // 35
////            if (value[colNumber].length() == 12) {
////                employeeDetails.setAadhaar(value[colNumber++]); // 36
////            } else {
////                throw new Exception("Aadhaar number needs to be 12 digits.");
////            }
////            employeeDetails.setUanNo(value[colNumber++]); // 37
////            employeeDetails.setMobileNumber(value[colNumber++]); // 38 // TODO not sure if handling country code needed or not
////            employeeDetails.setCountryOfOrigin(value[colNumber++]); // 39
////            employeeDetails.setDepartment(value[colNumber++]); // 40
////            employeeDetails.setDesignation(value[colNumber++]); // 41
////
////             if (StringUtils.isBlank(value[colNumber])) {  // checked at index 1
////                throw new Exception("Location field mandatory.");
////            }
////            employeeDetails.setLocation(value[colNumber++]); // 42
//
////            employeeDetails.setDateOfBirth(LocalDate.parse(value[5], formatter));   // need to change to localDate type
////            employeeDetails.setDateOfJoining(LocalDate.parse(value[6], formatter)); // need to change to localDate type
////            employeeDetails.setDateOfExit(value[7].equals("")? null : new Date(value[7]));
////            employeeDetails.setStatus(value[8]);
////            employeeDetails.setPermenantAddress(value[9]);
////            employeeDetails.setCorrespondenceAddress(value[10]);
////            employeeDetails.setCityType(value[11].charAt(0));
////            employeeDetails.setBankAcctAddress(value[14]);
////            employeeDetails.setBankAcctName(value[15]);
//
//            employeeDetails.setRowInsertBy("Unit Test Developer"); // TODO use authentication value received from request
//            /*
//            * Following fields are missing and can cause null exception in postgres
//            * dateOfExit
//            * permanentAddress
//            * correspondenceAddress
//            * bankAcctName
//            * bankAcctAddress
//            * */
//            // TODO temporary workaround
//            employeeDetails.setPermenantAddress("NA");
//            employeeDetails.setCorrespondenceAddress("NA");
//            employeeDetails.setBankAcctName("NA");
//            employeeDetails.setBankAcctAddress("NA");
//
//            employeeDetails = addNewEmployee(employeeDetails);
//
//            // Pass CTC detail for new employee added.
////            Map<String, EmployeeCtc> employeeCTC_forEmployeeId = new HashMap<>();
//
//            // Add following components to Employee_CTC table
//            /*
//             * Basic
//             * House Rent Allowance
//             * Standard Deduction
//             * Special Allowance
//             * Loyalty Bonus
//             * Gratuity
//             * Welfare Contribution */
//
//            // colNumber index from 43 to 49
//            for(int i = colNumber; i< 50 /* TODO limit it till number of columns of Excel*/ ; i++  ) {
//                EmployeeCtc employeeCtc = new EmployeeCtc();
//                employeeCtc.setEmployeeId(employeeDetails.getEmployeeId()); // pass the employeeID retrieved after employee insertion
//                employeeCtc.setCtcComponent(Constants.salaryComponentsForExcel.getOrDefault(i, "Component not found"));
//                employeeCtc.setAmount(Integer.parseInt(value[i]));
//                employeeCtc.setStatus(employeeDetails.getStatus());
//                employeeCtc.setFiscal(null); // fiscal not in excel template
//                employeeCtc.setNotes(null); // notes not in excel template
//                employeeCtc.setRowInsertBy("Unit Test Developer"); // TODO use authentication value received from request
//                employeeCtc.setRowInsertDate(new Date());
//                employeeCtc.setRowUpdateBy("Unit Test Developer"); // TODO use authentication value received from request
//                employeeCtc.setRowUpdateDate(new Date());
//
//                employeeCtcList.add(employeeCtc);
//            }
//
//        }
//        employeeCtcService.addEmployeeCtcService(employeeCtcList);
//
//    }

    private void  bulkImportEmployee(List<String[]> valueList) throws Exception {

        Validator validator = new Validator();

        List<EmployeeCtc> employeeCtcList = new ArrayList<>();

//        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        /*
         * employee id (mandatory)
         * Name field combined called as Name (mandatory) {first name last name} TODO middle name field missing
         * date of joining (dd-MMM-yyyy)  (mandatory)
         * date of birth (dd-MMM-yyyy)
         * Employee Status
         * Gender
         * Confirm Date
         * Email Address (work email)
         * Personal Email Address
         * pan number
         * Manager Employee Number
         * Father's Name
         * Spouse Name
         * isPhysicallyChallenged (1 or 0)
         * isInternationalEmployee (1 or 0)
         * Background check status ['Verified', 'Pending','Initiated', 'Rejected']
         * Background Verification completed on
         * Agency name
         * Background check Remarks
         * Emergency Contact Name
         * Emergency Contact Number
         * Bank Account Number
         * IFSC
         * Bank Account Type
         * Bank Name
         * Bank Branch
         * Salary Payment Mode
         * Name as per Bank Records
         * isEligibleForPF
         * PfNo
         * PF_Scheme
         * PF Joining Date (dd-MON-yyyy)
         * isEligibleForExcessEPF_Contribution (1 or 0)
         * isExistingMemberOfPF (1 or 0)
         * isEligibleForESI (yes or no)
         * Name as per Aadhaar
         * Aadhaar Number
         * Universal Account Number (UAN) (needs to be of type number)
         * Mobile Number
         * Country Of Origin
         * Department
         * Designation
         * Location (mandatory)
         * Basic
         * House Rent Allowance
         * Standard Deduction
         * Special Allowance
         * Loyalty Bonus
         * Gratuity
         * Welfare Contribution
         */

        //value list may be like list of string array and that string array contains the different values
        for (String[] value : valueList) {
            int colNumber = -1;
            EmployeeDetails employeeDetails = new EmployeeDetails();

            colNumber++; // 0
            if (StringUtils.isBlank(value[colNumber])) { // checked at index 0
                throw new Exception("Employee ID is mandatory");
            }
//            employeeDetails.setEmployeeId(Integer.parseInt(value[colNumber++])); // No effect as EmployeeID is serial // 0
            colNumber++; // TODO employee ID is entered via serial in database keeping it as null for now.

            if (StringUtils.isBlank(value[colNumber])) {  // checked at index 1
                throw new Exception("Name field mandatory.");
            }
            if (!validator.isNameValid(value[colNumber])){
                throw new Exception("Name must be in format");
            }
            // split fullName in excel based on space character as firstName and lastName.
            String[] fullName = value[colNumber++].split("\\s"); // 1

            long countOfName = fullName.length;
            // TODO still unsure how to split name string to separate first name and last name. eg: Rasipuram Krishnaswami Iyer Narayanaswami.
            //  What is first name and last name here? For now considering last name as Narayanaswami as of now.
            employeeDetails.setFirstName(Arrays.stream(fullName).limit(countOfName-1).collect(Collectors.joining(" ")));
            employeeDetails.setLastName(Arrays.stream(fullName).skip(countOfName-1).collect(Collectors.joining(" ")));
            // TODO still unsure how to split name string to separate first name and last name. eg: Rasipuram Krishnaswami Iyer Narayanaswami.
            employeeDetails.setDateOfJoining(new Date(value[colNumber++])); // need to change to localDate type // 2
            employeeDetails.setDateOfBirth(new Date(value[colNumber++]));   // need to change to localDate type // 3

            employeeDetails.setStatus(value[colNumber++]); // 4

//            employeeDetails.setGender(value[colNumber++]); // 5
            colNumber++; // GENDER skip 5

//            employeeDetails.setConfirmDate(new Date(value[colNumber++]));  // 6
            colNumber++;

//            employeeDetails.setEmailAddress(value[colNumber++]); // 7
            colNumber++;

//            employeeDetails.setPersonalEmailAddress(value[colNumber++]); // 8
            colNumber++;

            employeeDetails.setPan(value[colNumber++]); // 9

//            employeeDetails.setManagerEmployeeId(value[colNumber++]); // 10
            colNumber++;

//            employeeDetails.setFatherName(value[colNumber++]); // 11
            colNumber++;

//            employeeDetails.setSpouseName(value[colNumber++]); // 12
            colNumber++;

//            employeeDetails.setIsPhysicallyChallenged(Integer.parseInt(value[colNumber++]) == 1 ? 1 : 0 ); // 13
            colNumber++;

//            employeeDetails.setIsInternationEmployee(Integer.parseInt(value[colNumber++]) == 1 ? 1 : 0 ); // 14
            colNumber++;

//            employeeDetails.setBackgroundCheckStatus(value[colNumber++]); // 15
            colNumber++;

//            employeeDetails.setBackgroundVerificationCompleteDate(new Date(value[colNumber++])); // 16
            colNumber++;

//            employeeDetails.setAgencyName(value[colNumber++]); // 17
            colNumber++;

//            employeeDetails.setBackgroundCheckRemarks(value[colNumber++]); // 18
            colNumber++;

//            employeeDetails.setEmergencyContactName(value[colNumber++]); // 19
            colNumber++;

//            employeeDetails.setEmergencyContactNumber(value[colNumber++]); // 20
            colNumber++;

            // TODO add details in employee details or employeeCTC?
            //  CTC will only contain salary info, I guess remaining details about bank,IFSC, account type, Payment method will be employee details?
            employeeDetails.setBankAcctNo(value[colNumber++]); // 21
            employeeDetails.setBankIFSC(value[colNumber++]); // 22

//            employeeDetails.setBankAcctType(value[colNumber++]); // 23
            colNumber++;

//            employeeDetails.setBankName(value[colNumber++]); // 24
            colNumber++;

//            employeeDetails.setBankBranch(value[colNumber++]); // 25
            colNumber++;

//            employeeDetails.setPaymentMode(value[colNumber++]); // 26
            colNumber++;

//            employeeDetails.setFullNameAsPerBank(value[colNumber++]);// 27
            colNumber++;

            // TODO have employee PF eligibility check field in employee Details?
//            employeeDetails.setIsPfElligible(value[colNumber++]); // 28
            colNumber++;

//            employeeDetails.setPfNo(employeeDetails.getIsPfElligible().equalsIgnoreCase("yes") ? value[colNumber++] : "no"); // 29
            employeeDetails.setPfNo(value[colNumber++]); // 29

//            employeeDetails.setPfScheme(value[colNumber++]); // 30
            colNumber++;

//            employeeDetails.setPfJoiningDate(new Date(value[colNumber++])); // 31
            colNumber++;

//            employeeDetails.setIsElligibleExcessEpfContribution(Integer.parseInt(value[colNumber++]) == 1 ? 1 : 0); // 32
            colNumber++;

//            employeeDetails.setIsExistingPf(Integer.parseInt(value[colNumber++]) == 1 ? 1 : 0); // 33
            colNumber++;

//            employeeDetails.setIsEsiElligible(value[colNumber++]); // 34
            colNumber++;

//            employeeDetails.setFullNameAsPerAadhaar(value[colNumber++]); // 35
            colNumber++;

            if (value[colNumber].length() == 12) {
                employeeDetails.setAadhaar(value[colNumber++]); // 36
            } else {
                throw new Exception("Aadhaar number needs to be 12 digits.");
            }
            employeeDetails.setUanNo(value[colNumber++]); // 37

//            employeeDetails.setMobileNumber(value[colNumber++]); // 38 // TODO not sure if handling country code needed or not
            colNumber++;

//            employeeDetails.setCountryOfOrigin(value[colNumber++]); // 39
            colNumber++;

//            employeeDetails.setDepartment(value[colNumber++]); // 40
            colNumber++;

//            employeeDetails.setDesignation(value[colNumber++]); // 41
            colNumber++;

            if (StringUtils.isBlank(value[colNumber])) {  // checked at index 1
                throw new Exception("Location field mandatory.");
            }
            colNumber++;
//            employeeDetails.setLocation(value[colNumber++]); // 42

//            employeeDetails.setDateOfBirth(LocalDate.parse(value[5], formatter));   // need to change to localDate type
//            employeeDetails.setDateOfJoining(LocalDate.parse(value[6], formatter)); // need to change to localDate type
//            employeeDetails.setDateOfExit(value[7].equals("")? null : new Date(value[7]));
//            employeeDetails.setStatus(value[8]);
//            employeeDetails.setPermenantAddress(value[9]);
//            employeeDetails.setCorrespondenceAddress(value[10]);
//            employeeDetails.setCityType(value[11].charAt(0));
//            employeeDetails.setBankAcctAddress(value[14]);
//            employeeDetails.setBankAcctName(value[15]);

            employeeDetails.setRowInsertBy("Unit Test Developer"); // TODO use authentication value received from request
            /*
             * Following fields are missing and can cause null exception in postgres
             * dateOfExit
             * permanentAddress
             * correspondenceAddress
             * bankAcctName
             * bankAcctAddress
             * */
            // TODO temporary workaround
            employeeDetails.setPermenantAddress("NA");
            employeeDetails.setCorrespondenceAddress("NA");
            employeeDetails.setBankAcctName("NA");
            employeeDetails.setBankAcctAddress("NA");
            employeeDetails.setCityType('M'); // setting it as default

            employeeDetails = addNewEmployee(employeeDetails);

            // Pass CTC detail for new employee added.
//            Map<String, EmployeeCtc> employeeCTC_forEmployeeId = new HashMap<>();

            // Add following components to Employee_CTC table
            /*
             * Basic
             * House Rent Allowance
             * Standard Deduction
             * Special Allowance
             * Loyalty Bonus
             * Gratuity
             * Welfare Contribution */

            // colNumber index from 43 to 49
            for(int i = colNumber; i< 50 /* TODO limit it till number of columns of Excel*/ ; i++  ) {
                EmployeeCtc employeeCtc = new EmployeeCtc();
                employeeCtc.setEmployeeId(employeeDetails.getEmployeeId()); // pass the employeeID retrieved after employee insertion
                employeeCtc.setCtcComponent(Constants.salaryComponentsForExcel.getOrDefault(i, "Component not found"));
                employeeCtc.setAmount(Integer.parseInt(value[i]));
                employeeCtc.setStatus(employeeDetails.getStatus());
                employeeCtc.setFiscal("2021"); // fiscal not in excel template. Setting default
                employeeCtc.setNotes("empty notes"); // notes not in excel template
                employeeCtc.setRowInsertBy("Unit Test Developer"); // TODO use authentication value received from request
                employeeCtc.setRowInsertDate(new Date());
                employeeCtc.setRowUpdateBy("Unit Test Developer"); // TODO use authentication value received from request
                employeeCtc.setRowUpdateDate(new Date());

                employeeCtcList.add(employeeCtc);
            }

        }
        employeeCtcService.addEmployeeCtcService(employeeCtcList);

    }

}
