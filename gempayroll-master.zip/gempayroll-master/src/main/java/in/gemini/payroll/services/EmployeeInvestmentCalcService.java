package in.gemini.payroll.services;

import in.gemini.payroll.convertor.EmployeeInvestmentCalcConvertor;
import in.gemini.payroll.dto.EmployeeInvestmentCalcDTO;
import in.gemini.payroll.entity.EmployeeInvestmentCalc;
import in.gemini.payroll.repository.EmployeeDetailsRepository;
import in.gemini.payroll.repository.EmployeeInvestmentCalcRepository;
import in.gemini.payroll.repository.InvestLimitXrefRepo;
import in.gemini.payroll.repository.InvestViaXrefRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

import static java.lang.System.*;

@Service
public class EmployeeInvestmentCalcService {
    @Autowired
    private EmployeeInvestmentCalcRepository employeeInvestmentCalcRepository;

    @Autowired
    private EmployeeDetailsRepository employeeDetailsRepository;

    @Autowired
    private EmployeeInvestmentCalcConvertor employeeInvestmentCalcConvertor;

    private static final Logger log = LoggerFactory.getLogger(EmployeeInvestmentCalcService.class);


    public EmployeeInvestmentCalc /*EmployeeInvestmentCalcDTO*/ addEmployeeInvestment(EmployeeInvestmentCalc employeeInvestmentCalc) throws Exception {

        log.info("service addEmployeeInvestment {}",employeeInvestmentCalc);
        //check wether the employee exist or not
        //24/11/2021
        //no check needed as it will be already authenticated
//        if(!employeeDetailsRepository.findById(employeeInvestmentCalc.getEmployeeId()).isPresent()){
//            log.info("Employee with employee id "+employeeInvestmentCalc.getEmployeeId()+"doesn't exists");
//            throw new Exception("Employee with employee id "+employeeInvestmentCalc.getEmployeeId()+"doesn't exists");
//        }
        if(employeeInvestmentCalc.getEmpInvestCalcId()!=null) {
            log.info("Employee Investment calculation Id is auto generated don't add on your own");
            throw new Exception("Employee Investment calculation Id is auto genrated don't add on your own");
        }
        employeeInvestmentCalc.setRowInsertDate(new Date(System.currentTimeMillis()));
        employeeInvestmentCalc.setRowUpdateDate(new Date(System.currentTimeMillis()));
//        return employeeInvestmentCalcConvertor.convertToEmployeeInvestmentCalcDTO(employeeInvestmentCalcRepository.save(employeeInvestmentCalc));
        return  employeeInvestmentCalcRepository.save(employeeInvestmentCalc);
    }

}