package in.gemini.payroll.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="EMPLOYEE_INVESTMENT_DECLARATION", schema = "payroll")
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeInvestmentDeclaration {

    @Id
    @Column(name = "EMP_INVEST_DECL_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long empInvestDeclId;

    @Column(name = "EMPLOYEE_ID")
    private Integer employeeId;

    @Column(name = "INVESTMENT_VIA_ID")
    private Long investmentViaId;

    @Column(name = "AMOUNT",nullable = false)
    private Integer amount;
    @Column(name = "FISCAL",nullable = false)
    private String fiscal;
    @Column(name = "STATUS",nullable = false)
    private String status;

    @Column(name="ROW_INSERT_BY",nullable = false)
    private String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE",nullable = false)
    private Date rowInsertDate;

    @Column(name = "ROW_UPDATE_BY",nullable = false)
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE",nullable = false)
    private Date rowUpdateDate;


    public Long getEmpInvestDeclId() {
        return empInvestDeclId;
    }

    public void setEmpInvestDeclId(Long empInvestDeclId) {
        this.empInvestDeclId = empInvestDeclId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public Long getInvestmentViaId() {
        return investmentViaId;
    }

    public void setInvestmentViaId(Long investmentViaId) {
        this.investmentViaId = investmentViaId;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getFiscal() {
        return fiscal;
    }

    public void setFiscal(String fiscal) {
        this.fiscal = fiscal;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    @Override
    public String toString() {
        return "EmployeeInvestmentDeclaration{" +
                "empInvestDeclId=" + empInvestDeclId +
                ", employeeId='" + employeeId + '\'' +
                ", investmentViaId=" + investmentViaId +
                ", amount=" + amount +
                ", fiscal='" + fiscal + '\'' +
                ", status='" + status + '\'' +
                ", rowInsertBy='" + rowInsertBy + '\'' +
                ", rowInsertDate=" + rowInsertDate +
                ", rowUpdateBy='" + rowUpdateBy + '\'' +
                ", rowUpdateDate=" + rowUpdateDate +
                '}';
    }
}
