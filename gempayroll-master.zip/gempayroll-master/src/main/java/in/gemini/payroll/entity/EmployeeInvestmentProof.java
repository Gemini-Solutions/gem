package in.gemini.payroll.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;

@Entity
@Table(name="EMPLOYEE_INVESTMENT_PROOF", schema = "payroll")
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeInvestmentProof {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EMP_INVEST_PROOF_ID")
	@ApiParam(value="Employee investment proof id(This is auto generated id)")
    private Long empInvestProofId;
	 
	@ApiParam(value="Employee investment declaration id", required = true)
	@Column(name = "EMP_INVEST_DECL_ID")
	private Integer empInvestDeclId;
	
	@ApiParam(value="Employee investment declaration amount", required = true)
	@Column(name = "AMOUNT")
	private Integer amount;
	
	@ApiParam(value="Employee investment declaration proof1. This will store investment proof1 path")
	@Column(name = "PROOF_1")
	private String proof1;
	
	@ApiParam(value="Employee investment declaration proof2. This will store investment proof2 path")
	@Column(name = "PROOF_2")
	private String proof2;
	
	@ApiParam(value="Employee investment declaration proof3. This will store investment proof3 path")
	@Column(name = "PROOF_3")
	private String proof3;
	
	@ApiParam(value="Employee investment declaration status", allowableValues = "Pending", required = true)
	@Column(name = "STATUS")
	private String status;
	
	@ApiParam(value="Add any comment regarding investment proof")
	@Column(name = "NOTES")
	private String notes;
	
	@ApiParam(value="User name who is trying to insert data", required = true)
	@Column(name="ROW_INSERT_BY")
	private String rowInsertBy;
	
	@ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
	@Column(name="ROW_INSERT_DATE")
	private Date rowInsertDate;
	
	@ApiParam(value="User name who is trying to update data")
	@Column(name="ROW_UPDATE_BY")
	private String rowUpdateBy;
	
	@ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
	@Column(name="ROW_UPDATE_DATE")
	private Date rowUpdateDate;

	public Long getEmpInvestProofId() {
		return empInvestProofId;
	}

	public void setEmpInvestProofId(Long empInvestProofId) {
		this.empInvestProofId = empInvestProofId;
	}

	public Integer getEmpInvestDeclId() {
		return empInvestDeclId;
	}

	public void setEmpInvestDeclId(Integer empInvestDeclId) {
		this.empInvestDeclId = empInvestDeclId;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public String getProof1() {
		return proof1;
	}

	public void setProof1(String proof1) {
		this.proof1 = proof1;
	}

	public String getProof2() {
		return proof2;
	}

	public void setProof2(String proof2) {
		this.proof2 = proof2;
	}

	public String getProof3() {
		return proof3;
	}

	public void setProof3(String proof3) {
		this.proof3 = proof3;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getRowInsertBy() {
		return rowInsertBy;
	}

	public void setRowInsertBy(String rowInsertBy) {
		this.rowInsertBy = rowInsertBy;
	}

	public Date getRowInsertDate() {
		return rowInsertDate;
	}

	public void setRowInsertDate(Date rowInsertDate) {
		this.rowInsertDate = rowInsertDate;
	}

	public String getRowUpdateBy() {
		return rowUpdateBy;
	}

	public void setRowUpdateBy(String rowUpdateBy) {
		this.rowUpdateBy = rowUpdateBy;
	}

	public Date getRowUpdateDate() {
		return rowUpdateDate;
	}

	public void setRowUpdateDate(Date rowUpdateDate) {
		this.rowUpdateDate = rowUpdateDate;
	}

	@Override
	public String toString() {
		return "EmployeeInvestmentProof [empInvestProofId=" + empInvestProofId + ", empInvestDeclId=" + empInvestDeclId
				+ ", amount=" + amount + ", proof1=" + proof1 + ", proof2=" + proof2 + ", proof3=" + proof3
				+ ", status=" + status + ", notes=" + notes + ", rowInsertBy=" + rowInsertBy + ", rowInsertDate="
				+ rowInsertDate + ", rowUpdateBy=" + rowUpdateBy + ", rowUpdateDate=" + rowUpdateDate + "]";
	}

}
