package in.gemini.payroll.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.models.auth.In;

import javax.persistence.*;
import java.util.Date;

@Table(name = "EMPLOYEE_TAX_REGIME", schema = "payroll")
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmpTaxRegime {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EMP_TAX_REGIME_ID")
    private Long empTaxRegimeId;

    @Column(name = "EMPLOYEE_ID")
    private Integer employeeId;

    @ApiModelProperty(value="new or old",example = "OLD")
    @Column(name = "TAX_REGIME_TYPE",nullable = false)
    private String taxRegimeType;

    @Column(name = "FISCAL",nullable = false)
    private String FISCAL;


    @Column(name="ROW_INSERT_BY",nullable = false)
    private String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE",nullable = false)
    private Date rowInsertDate;

    @Column(name = "ROW_UPDATE_BY",nullable = false)
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE",nullable = false)
    private Date rowUpdateDate;


    public Long getEmpTaxRegimeId() {
        return empTaxRegimeId;
    }

    public void setEmpTaxRegimeId(Long empTaxRegimeId) {
        this.empTaxRegimeId = empTaxRegimeId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getTaxRegimeType() {
        return taxRegimeType;
    }

    public void setTaxRegimeType(String taxRegimeType) {
        this.taxRegimeType = taxRegimeType;
    }

    public String getFISCAL() {
        return FISCAL;
    }

    public void setFISCAL(String FISCAL) {
        this.FISCAL = FISCAL;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    @Override
    public String toString() {
        return "EmpTaxRegime{" +
                "empTaxRegimeId=" + empTaxRegimeId +
                ", employeeId='" + employeeId + '\'' +
                ", taxRegimeType='" + taxRegimeType + '\'' +
                ", FISCAL='" + FISCAL + '\'' +
                ", rowInsertBy='" + rowInsertBy + '\'' +
                ", rowInsertDate=" + rowInsertDate +
                ", rowUpdateBy='" + rowUpdateBy + '\'' +
                ", rowUpdateDate=" + rowUpdateDate +
                '}';
    }
}
