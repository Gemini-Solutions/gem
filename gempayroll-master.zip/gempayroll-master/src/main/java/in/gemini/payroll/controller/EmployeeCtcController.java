package in.gemini.payroll.controller;


import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.EmployeeCtc;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import in.gemini.payroll.services.EmployeeCtcService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/employee-ctc")
public class EmployeeCtcController {

    @Autowired
    private EmployeeCtcService employeeCtcService;

    private static final Logger log = LoggerFactory.getLogger(EmployeeCtcController.class);


    /*
    The request body can be or should be changed , there is no need to have the array
    of employeectc, but just one common employeectc json with CTC options as array
     */
    @ApiOperation(value = "API to add employee CTC")
    @PostMapping("/addEmployeeCtc")
    public ResponseClass addEmployeeCtc(@RequestBody List<EmployeeCtc> employeeCtc){
        log.info("Inside Add employee CTC - data: " + employeeCtc);
        try {
            log.info("completed adding employee ctc - data : " + employeeCtc);
            return new ResponseClass(employeeCtcService.addEmployeeCtcService(employeeCtc), "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in adding employee ctc - data" + employeeCtc+"\nException : "+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to get all employee CTC")
    @GetMapping("/allEmployeeCtc")
    public ResponseClass getAllEmployeeCtc(){
        log.info("Inside get all Employee CTC");
        List<EmployeeCtc> empCtcList = new ArrayList<>();
        try {
            empCtcList = employeeCtcService.getAllEmployeeCtcService();
            log.info("Successfully get all employee Ctc");
            return new ResponseClass(empCtcList, "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in getting all employee ctc, Exception : "+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to get employee ctc detail by employee id")
    @GetMapping("/getEmployeeCtcDetail")
    public ResponseClass getEmployeeCtcDetail(@RequestParam Integer employeeId){
        log.info("Inside get Employee Ctc detail - " + employeeId);
        List<EmployeeCtc> employeeCtcList = new ArrayList<>();
        try {
            employeeCtcList = employeeCtcService.getEmployeeCtcByIdService(employeeId);
            log.info("Successfully get Employee Ctc details ,id- "+employeeId);
            return new ResponseClass(employeeCtcList, "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in get employee ctc detail - id: " + employeeId+"\n Exception :"+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to get employee ctc detail by employee ctc id")
    @GetMapping("/getEmployeeCtcDetailById")
    public ResponseClass getEmployeeCtcByCtcId(@RequestParam Long employeeCtcId){
        log.info("Inside get Employee Ctc by id - " + employeeCtcId);
        EmployeeCtc employeeCtc = null;
        try {
            employeeCtc = employeeCtcService.getEmployeeCtcByCtcIdService(employeeCtcId);
            log.info("Successfully get Employee Ctc details for id- " + employeeCtcId);
            return new ResponseClass(employeeCtc, "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in get employee ctc detail - id:" + employeeCtcId+"\n Exception: "+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to delete a Employee CTC using employee ctc id")
    @DeleteMapping("/deleteEmployeeCtcById")
    public ResponseClass deleteEmployeeCtcById(@RequestParam Long employeeCtcId){
        log.info("Inside delete Employee Ctc By id - " + employeeCtcId);
        try {
            employeeCtcService.deleteEmployeeCtcByIdService(employeeCtcId);
            log.info("Successfully deleted employee ctc for id - " + employeeCtcId);
            return new ResponseClass("Employee Ctc deleted successfully", "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in deleting employee ctc for id - " + employeeCtcId+"\nException :"+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to update a Employee CTC")
    @PutMapping("/updateEmployeeCTC")
    public ResponseClass updateEmployeeCtc(@RequestBody EmployeeCtc employeeCtc){
        log.info("Inside update Employee CTC - " + employeeCtc.toString());
        try {
            employeeCtcService.updateEmployeeCtcService(employeeCtc);
            log.info("Successfully updated employee ctc for employee - " + employeeCtc);
            return new ResponseClass("Employee CTC updated successfully", "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in updating Employee CTC for employee - " + employeeCtc+"\n Exception:"+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
