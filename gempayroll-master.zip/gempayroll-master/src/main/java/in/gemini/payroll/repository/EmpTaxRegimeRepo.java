package in.gemini.payroll.repository;

import in.gemini.payroll.entity.EmpTaxRegime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface EmpTaxRegimeRepo extends JpaRepository<EmpTaxRegime,Long> {

    List<EmpTaxRegime> findByEmployeeId(Integer employeeId);
}