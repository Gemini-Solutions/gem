package in.gemini.payroll.convertor;

import in.gemini.payroll.dto.EmployeeInvestmentCalcDTO;
import in.gemini.payroll.entity.EmployeeInvestmentCalc;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.Converter;

@Component
public class EmployeeInvestmentCalcConvertor {
    @Autowired
    private ModelMapper modelMapper;

    private static final Logger log = LoggerFactory.getLogger(EmployeeInvestmentCalcConvertor.class);

    public EmployeeInvestmentCalcDTO convertToEmployeeInvestmentCalcDTO(EmployeeInvestmentCalc employeeInvestmentCalc) throws Exception {
        log.info("Converting to dto object ");
        try {
            modelMapper.getConfiguration()
                    .setMatchingStrategy(MatchingStrategies.LOOSE);
            EmployeeInvestmentCalcDTO employeeInvestmentCalcDTO=modelMapper.map(employeeInvestmentCalc, EmployeeInvestmentCalcDTO.class);
            log.info("Converted to dto object");
            return employeeInvestmentCalcDTO;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Unable to convert"+employeeInvestmentCalc+"to DTO");
            throw new Exception(e.getMessage());
        }
    }
}