package in.gemini.payroll.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name="CTC_STRUCTURE", schema = "payroll")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CtcStructure {
	
	@Id
	@Column(name="CTC_COMPONENT")
	private String ctcComponent;

	@ApiModelProperty(value = "Type of the component if fixed or variable", example = "Y")
	@JsonFormat(pattern = "Fixed/Variable")
	@Column(name="TYPE")
	private String type;
	
	@ApiModelProperty(value = "value as char(Y/N)", example = "Y")
    @JsonFormat(pattern = "Y/N")
	@Column(name="TAXABLE")
	private char taxable;

	@ApiModelProperty(hidden = true)
	@Column(name="ROW_INSERT_BY")
	private String rowInsertBy;
	
//	@ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
//    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @ApiModelProperty(hidden = true)
	@Column(name="ROW_INSERT_DATE")
	private Timestamp rowInsertDate;
	@ApiModelProperty(hidden = true)
	@Column(name="ROW_UPDATE_BY")
	private String rowUpdateBy;
	
//	@ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
//    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @ApiModelProperty(hidden = true)
    @Column(name="ROW_UPDATE_DATE")
	private Timestamp rowUpdateDate;

	public CtcStructure() {
		
	}
	
	public CtcStructure(String ctcComponent, String type, char taxable, String rowInsertBy,Timestamp rowInsertDate,
			String rowUpdateBy, Timestamp rowUpdateDate) {
		super();
		this.ctcComponent = ctcComponent;
		this.type = type;
		this.taxable = taxable;
		this.rowInsertBy = rowInsertBy;
		this.rowInsertDate = rowInsertDate;
		this.rowUpdateBy = rowUpdateBy;
		this.rowUpdateDate = rowUpdateDate;
	}

	public String getCtcComponent() {
		return ctcComponent;
	}

	public void setCtcComponent(String ctcComponent) {
		this.ctcComponent = ctcComponent;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public char getTaxable() {
		return taxable;
	}

	public void setTaxable(char taxable) {
		this.taxable = taxable;
	}

	public String getRowInsertBy() {
		return rowInsertBy;
	}

	public void setRowInsertBy(String rowInsertBy) {
		this.rowInsertBy = rowInsertBy;
	}

	public Timestamp getRowInsertDate() {
		return rowInsertDate;
	}

	public void setRowInsertDate(Timestamp rowInsertDate) {
		this.rowInsertDate = rowInsertDate;
	}

	public String getRowUpdateBy() {
		return rowUpdateBy;
	}

	public void setRowUpdateBy(String rowUpdateBy) {
		this.rowUpdateBy = rowUpdateBy;
	}

	public Timestamp getRowUpdateDate() {
		return rowUpdateDate;
	}

	public void setRowUpdateDate(Timestamp rowUpdateDate) {
		this.rowUpdateDate = rowUpdateDate;
	}

	@Override
	public String toString() {
		return "CtcStructure [ctcComponent=" + ctcComponent + ", type=" + type + ", taxable=" + taxable
				+ ", rowInsertBy=" + rowInsertBy + ", rowInsertDate=" + rowInsertDate + ", rowUpdateBy=" + rowUpdateBy
				+ ", rowUpdateDate=" + rowUpdateDate + "]";
	}
	
}
