package in.gemini.payroll.repository;

import in.gemini.payroll.entity.InvestmentLimitXref;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface InvestLimitXrefRepo extends JpaRepository<InvestmentLimitXref,String> {
}
