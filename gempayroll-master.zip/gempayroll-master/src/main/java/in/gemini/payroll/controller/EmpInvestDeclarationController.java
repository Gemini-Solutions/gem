package in.gemini.payroll.controller;


import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.EmployeeInvestmentDeclaration;

import in.gemini.payroll.services.EmpInvestDeclarationService;

import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/employee-Invest-Declare")
public class EmpInvestDeclarationController {

    @Autowired
    private EmpInvestDeclarationService empInvestDeclarationService;

    private static final Logger log = LoggerFactory.getLogger(EmpInvestDeclarationController.class);

    @ApiOperation(value = "API to add investment declaration")
    @PostMapping("/addInvestmentDeclaration")
    public ResponseClass addInvestmentDeclaration(@RequestBody EmployeeInvestmentDeclaration employeeInvestmentDeclaration){
        log.info("Inside add Investment Declaration Controller , data - " + employeeInvestmentDeclaration);
        try {
            EmployeeInvestmentDeclaration response = empInvestDeclarationService.addInvestmentDeclaration(employeeInvestmentDeclaration);
            log.info("completed adding Investment Declaration for data- " + employeeInvestmentDeclaration);
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in adding Investment Declaration with data " + employeeInvestmentDeclaration.toString()+"\nException :"+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to get all Investment Declarations")
    @GetMapping("/allInvestDeclaration")
    public ResponseClass getAllInvestDeclaration(){
        log.info("Inside get all Employee CTC");
        List<EmployeeInvestmentDeclaration> employeeInvestmentDeclarationList = new ArrayList<>();
        try {
            employeeInvestmentDeclarationList = empInvestDeclarationService.getAllInvestDeclaration();
            log.info("Successfully get all Investment Declaration ");
            return new ResponseClass(employeeInvestmentDeclarationList, "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in getting all Investment Declaration ,Exception :"+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to get Employee Invest Declaration by employee id")
    @GetMapping("/getEmployeeInvestDeclarationByEmpId")
    public ResponseClass getEmployeeInvestDeclarationByEmpId(@RequestParam Integer employeeId)
    {
        log.info("Inside get employee declaration by employee id"+employeeId);
        List<EmployeeInvestmentDeclaration> response = new ArrayList<>();
        try {
            response = empInvestDeclarationService.getEmployeeInvestDeclarationByEmpId(employeeId);
            log.info("Successfully get Employee Investment Declaration , employee_id :"+employeeId);
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in getting employee declaration for id - " + employeeId+"\n Exception :"+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }


    @ApiOperation(value = "API to get Employee Invest Declaration by employee investment declaration id")
    @GetMapping("/getEmployeeInvestDeclaration")
    public ResponseClass getEmployeeInvestDeclaration(@RequestParam Long empDeclarationId){
        log.info("Inside get employee declaration id - " + empDeclarationId);
        EmployeeInvestmentDeclaration employeeInvestmentDeclaration=null;
        try {
            employeeInvestmentDeclaration = empInvestDeclarationService.getEmployeeInvestDeclaration(empDeclarationId);
            log.info("Successfully get Employee Investment Declaration, employee_declaration_id: "+empDeclarationId);
            return new ResponseClass(employeeInvestmentDeclaration, "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in getting employee declaration for id - " + empDeclarationId+
                    "\n Exception:"+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to delete a employee investment declaration using emp_invest_declaration_id")
    @DeleteMapping("/deleteEmployeeInvestmentDecById")
    public ResponseClass deleteEmployeeInvestDecById(@RequestParam Long empInvDecId){
        log.info("Inside delete Employee Investment Declaration By Id - " + empInvDecId);
        try {
            empInvestDeclarationService.deleteEmployeeInvestmentDecById(empInvDecId);
            log.info("Successfully deleted Employee Investment Declaration By Id - " + empInvDecId);
            return new ResponseClass("Employee Investment Declaration By Id deleted successfully", "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in deleting Employee Investment Declaration for Id - " + empInvDecId+
                    "\n Exception : "+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to update a employee investment declaration")
    @PutMapping("/updateEmployeeInvestmentDec")
    public ResponseClass updateEmployeeInvestmentDec(@RequestBody EmployeeInvestmentDeclaration employeeInvestmentDeclaration){
        log.info("Inside update Employee Investment Declaration - " + employeeInvestmentDeclaration.toString());
        try {
            empInvestDeclarationService.updateEmployeeInvestmentDec(employeeInvestmentDeclaration);
            log.info("Successfully updated Employee Investment Declaration - " + employeeInvestmentDeclaration);
            return new ResponseClass("Employee Investment Declaration ", "SUCCESS", HttpStatus.OK);
        }catch(Exception e) {
            e.printStackTrace();
            log.error("Error in updating Employee Investment Declaration- " + employeeInvestmentDeclaration+
                    "\n Exception: "+e);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
