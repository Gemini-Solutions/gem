package in.gemini.payroll.services;

import in.gemini.payroll.entity.EmpTaxRegime;
import in.gemini.payroll.repository.EmpTaxRegimeRepo;
import in.gemini.payroll.repository.EmployeeDetailsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class EmpTaxRegimeService {
    @Autowired
    private EmpTaxRegimeRepo empTaxRegimeRepo;
    @Autowired
    private EmployeeDetailsRepository employeeDetailsRepository;

    private static final Logger log = LoggerFactory.getLogger(EmpTaxRegimeService.class);


    public EmpTaxRegime addEmpTaxRegime(EmpTaxRegime empTaxRegime) throws Exception {
        log.info("Inside Add employee Tax Regime Service, data:"+empTaxRegime);

        //checking if the given employee exist or not
        if(!employeeDetailsRepository.findById(empTaxRegime.getEmployeeId()).isPresent())
        {
            log.info("Employee does not exist with id : "+empTaxRegime.getEmployeeId());
            throw new Exception("Employee does not exist with id : "+empTaxRegime.getEmployeeId());
        }

        //avoiding any injection using emp tax regime id
        if(empTaxRegime.getEmpTaxRegimeId() != null)
        {
            log.info("employee tax regime id is auto generated, don't push 'employee tax regime id' while creating");
            throw new Exception("employee tax regime id is auto generated, don't push 'employee tax regime id' while creating");
        }

        empTaxRegime.setRowUpdateBy(empTaxRegime.getRowInsertBy());
        empTaxRegime.setRowInsertDate(new Date(System.currentTimeMillis()));
        empTaxRegime.setRowUpdateDate(new Date(System.currentTimeMillis()));

        return empTaxRegimeRepo.save(empTaxRegime);
    }

    //get employee tax by regime id
    @Transactional(readOnly = true)
    public EmpTaxRegime getEmpTaxRegimeById(Long empTaxRegimeId) throws Exception {

        log.info("Inside the getEmpTaxRegimeById service, id : "+empTaxRegimeId);
        if(!empTaxRegimeRepo.findById(empTaxRegimeId).isPresent())
        {
            log.info("Employee Tax Regime with id :"+ empTaxRegimeId+" does not exist");
            throw new Exception("Employee Tax Regime with id :"+ empTaxRegimeId+" does not exist");
        }

        return empTaxRegimeRepo.findById(empTaxRegimeId).get();

    }

    //get all the employee tax regime list for an employee by using employee id
    @Transactional(readOnly = true)
    public List<EmpTaxRegime> getEmpTaxRegimeByEmpId(Integer employeeId) throws Exception {
        log.info("Inside getEmpTaxRegimeByEmpId Service, emp_id:"+employeeId);
        if(!employeeDetailsRepository.findById(employeeId).isPresent()){
            log.info("No Employee exist with id :"+employeeId);
            throw new Exception("No Employee exist with id :"+employeeId);
        }

        if(empTaxRegimeRepo.findByEmployeeId(employeeId).isEmpty())
        {
            log.info("No Employee Tax Regime Record Exist with employee id :"+employeeId);
            throw new Exception("No Employee Tax Regime Record Exist with employee id :"+employeeId);
        }

        return empTaxRegimeRepo.findByEmployeeId(employeeId);
    }

    public void updateEmpTaxRegime(EmpTaxRegime empTaxRegime) throws Exception {
        log.info("Inside update Tax regime Service, data :"+empTaxRegime);
        if(!empTaxRegimeRepo.findById(empTaxRegime.getEmpTaxRegimeId()).isPresent())
        {
            log.info("No Employee tax regime exist with id :"+empTaxRegime.getEmpTaxRegimeId());
            throw new Exception("No Employee tax regime exist with id :"+empTaxRegime.getEmpTaxRegimeId());
        }

        //checking for employee whether the given employee exists or not
        if(!employeeDetailsRepository.findById(empTaxRegime.getEmployeeId()).isPresent())
        {
            log.info("Employee does not exist with id : "+empTaxRegime.getEmployeeId());
            throw new Exception("Employee does not exist with id : "+empTaxRegime.getEmployeeId());
        }

        EmpTaxRegime empTaxRegimeFromRepo = empTaxRegimeRepo.findById(empTaxRegime.getEmpTaxRegimeId()).get();

        //not updating the employee_tax_regime_id,row_insert_by,row_insert_date
        empTaxRegimeFromRepo.setTaxRegimeType(empTaxRegime.getTaxRegimeType());
        empTaxRegimeFromRepo.setEmployeeId(empTaxRegime.getEmployeeId());
        empTaxRegimeFromRepo.setFISCAL(empTaxRegime.getFISCAL());
        empTaxRegimeFromRepo.setRowUpdateBy(empTaxRegime.getRowUpdateBy());
        empTaxRegimeFromRepo.setRowUpdateDate(new Date(System.currentTimeMillis()));
        empTaxRegimeRepo.save(empTaxRegimeFromRepo);

    }

    public void deleteEmpTaxRegime(Long empTaxRegimeId) throws Exception {
        log.info("Inside the Delete Employee Tax Regime Service");
        if(!empTaxRegimeRepo.existsById(empTaxRegimeId))
        {
            log.info("No Employee Tax Regime Exist for id : "+empTaxRegimeId);
            throw new Exception("No Employee Tax Regime Exist for id : "+empTaxRegimeId);
        }

        empTaxRegimeRepo.deleteById(empTaxRegimeId);

    }

    @Transactional(readOnly = true)
    public List<EmpTaxRegime> getALlEmpTaxRegime() throws Exception {
        log.info("Inside getAllEmpTaxRegime Service");
        if (empTaxRegimeRepo.findAll().isEmpty())
        {
            log.info("No Employee Tax Regime Exist");
            throw new Exception("No Employee Tax Regime Exist");
        }

        return empTaxRegimeRepo.findAll();
    }
}
