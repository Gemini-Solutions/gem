package in.gemini.payroll.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.EmployeeInvestmentProof;
import in.gemini.payroll.services.EmployeeInvestmentProofService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/empInvestProof")
public class InvestmentProofController {
	
	private static final Logger log = LoggerFactory.getLogger(InvestmentProofController.class);
	
	@Autowired
	EmployeeInvestmentProofService investProofService;
	
	@PostMapping("/addInvestProof")
	@ApiOperation(value = "add investment proof")
	public ResponseClass uploadFile(@ModelAttribute EmployeeInvestmentProof empInvestProof, @ApiParam(value="Investment proof document 1", required = true) @RequestPart(name="file1", required=false) MultipartFile file1, @ApiParam(value="Investment proof document 2") @RequestPart(name="file2", required=false) MultipartFile file2, @ApiParam(value="Investment proof document 3") @RequestPart(name="file3", required=false) MultipartFile file3, @RequestParam String employeeId) {
	    try {
	    	EmployeeInvestmentProof response = investProofService.saveInvestmentProof(empInvestProof, file1, file2, file3, employeeId);
	    	
	      log.info("Investment proof successfully added for : " + employeeId + " " + empInvestProof.getEmpInvestDeclId());
	      return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
	    } catch (Exception e) {
	    	e.printStackTrace();
			log.error("Error in uploading investment proof for : " + employeeId + " " + empInvestProof.getEmpInvestDeclId());
	      return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.EXPECTATION_FAILED);
	    }
	}
	
	@DeleteMapping("/deleteInvestProof")
	@ApiOperation(value = "delete investment proof by id")
	public ResponseClass deleteFile(@ApiParam(value="Employee investment proof id", required = true) @RequestParam Long empInvestProofId) {
	    try {
	    	investProofService.deleteInvestmentProof(empInvestProofId);
	    	
	      log.info("Investment proof successfully deleted");
	      return new ResponseClass("Investment proof successfully deleted", "SUCCESS", HttpStatus.OK);
	    } catch (Exception e) {
	    	e.printStackTrace();
			log.error("Error in deleting investment proof");
	      return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.EXPECTATION_FAILED);
	    }
	}
	
	@PutMapping("/updateInvestProof")
	@ApiOperation(value = "API to update investment proof status Approved/Rejected")
	public ResponseClass updateStatus(@ApiParam(value="Employee investment proof id", required = true) @RequestParam Long empInvestProofId, 
			@ApiParam(value = "Approve or Reject", allowableValues = "Approve, Reject", required = true) @RequestParam String status,
			@ApiParam(value="User name who is trying to update status", required = true) @RequestParam String userName) {
	    try {
	    	EmployeeInvestmentProof response = investProofService.updateProofStatus(empInvestProofId, status, userName);
	    	
	      log.info("Investment proof successfully deleted");
	      return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
	    } catch (Exception e) {
	    	e.printStackTrace();
			log.error("Error in deleting investment proof");
	      return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.EXPECTATION_FAILED);
	    }
	}

}
