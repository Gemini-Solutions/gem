package in.gemini.payroll.controller;


import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.EmployeeDetails;
import in.gemini.payroll.services.EmployeeService;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    private static final Logger log = LoggerFactory.getLogger(EmployeeController.class);

    @PostMapping(value = "/addNewEmployee")
    @ApiOperation(value = "Insert new Employee details", notes = "Add a new employee into payroll database. Provide userCreatedBy and rowUpdatedBy as same")
    public ResponseClass addNewEmployee(@RequestBody EmployeeDetails employeeDetails) {
        log.info("REST new employee add start");
        EmployeeDetails response;
        try {
            response = employeeService.addNewEmployee(employeeDetails);
            log.info("REST new employee add end");
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/getAllEmployees")
    @ApiOperation(value = "Get all employees", notes = "Get details of all the employees")
    public ResponseClass getAllEmployees() {
        log.info("REST get all employees start");
        List<EmployeeDetails> employeeDetailsList;
        try {
            employeeDetailsList = employeeService.getAllEmployees();
            log.info("REST get all employees end with size {}", employeeDetailsList.size());
            return new ResponseClass(employeeDetailsList, "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST getAllEmployees error");
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PutMapping(value = "/updateEmployee")
    @ApiOperation(value = "Update an employee", notes = "Pass whole JSON to update employee details")
    public ResponseClass updateEmployee(@RequestBody EmployeeDetails EmployeeDetails) {
        log.info("REST update employee start");
        EmployeeDetails response;

        try {
            response = employeeService.updateEmployee(EmployeeDetails);
            log.info("REST update employee end");
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            log.error("Service updateEmployee Error: {}", e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }

    @GetMapping(value = "/getEmployeeById/{id}")
    @ApiOperation(value = "Get employee info by employee id")
    public ResponseClass getEmployeeById(@PathVariable(value = "id") Integer id) {
        EmployeeDetails response;
        log.info("REST get employee of id {}", id);
        try {
            response = employeeService.getEmployeeById(id);
            log.info("REST get employee by id end");
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST getEmployeeById error id {}", id);
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping(value = "/deleteEmployeeById/{id}")
    @ApiOperation(value = "Delete employee info by providing employee id")
    public ResponseClass deleteEmployeeById(@PathVariable(value = "id") Integer id) {
        log.info("REST delete employee of id {}", id);
        try {
            employeeService.deleteEmployeeById(id);
            log.info("REST delete employee by id end");
            return new ResponseClass("Employee deletion successful", "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST deleteEmployeeById error {}", e.getMessage());
            return new ResponseClass("Employee deletion fail", "FAIL", HttpStatus.OK);
        }
    }

    @PostMapping(value = "/bulkImportEmployee")
    public ResponseClass bulkImportEmployeeCSV(@RequestParam("file") MultipartFile file) {
        log.info("REST bulk import employees start");
        String fileName = file.getOriginalFilename();
        try {
//            if (StringUtils.isNotEmpty(fileName) && fileName.endsWith(".csv")) {
//                employeeService.parseBulkImportEmployeeCSV(file.getInputStream());
//            }
//            else
                if (StringUtils.isNotEmpty(fileName) && (fileName.endsWith(".xlsx") || fileName.endsWith(".xls")))
            {
                employeeService.parseBulkImportEmployeeExcel(file.getInputStream());

            }
            else{
                log.info("REST bulk import employees end |  filetype not Excel");
                throw new Exception("File type not excel (xlsx/xls)");
                            }
            log.info("REST bulk import employees end");
            return new ResponseClass("Rows inserted ", "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.info("REST bulk import employees Exception: {}", e.getMessage());
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, e.getLocalizedMessage());
        }
    }


}
