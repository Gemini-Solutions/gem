package in.gemini.payroll.controller;

import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.EmployeeMonthlyPayroll;
import in.gemini.payroll.services.EmployeeMonthlyPayrollService;
import in.gemini.payroll.services.PayrollService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/payslip")
public class EmployeeMonthlyPayrollController {
    @Autowired
    EmployeeMonthlyPayrollService employeeMonthlyPayrollService;
    @Autowired
    PayrollService payrollService;
    private static final Logger log = LoggerFactory.getLogger(EmployeeMonthlyPayrollController.class);

    @ApiOperation(value = "Api to get monthly payslip",notes = "get monthly payslip")
    @GetMapping("/getPayslip")
    public ResponseClass getMonthlyPayslip(@RequestParam Integer employeeId,@RequestParam Integer payslipYear,@RequestParam Integer payslipMonth)
    {
        log.info("REST inside getMonthlyPayslip employeeId:{} | payslipYear:{} | payslipMonth: {}",employeeId,payslipYear,payslipMonth);
        Optional<List<EmployeeMonthlyPayroll>> employeeMonthlyPayrollList;
        try{
           employeeMonthlyPayrollList=employeeMonthlyPayrollService.getMonthlyPayslip(employeeId,payslipYear,payslipMonth);
           log.info("Successfully fetched monthly payslip");
           return new ResponseClass(employeeMonthlyPayrollList,"success", HttpStatus.OK);
        }
        catch (Exception e){
            e.printStackTrace();
            log.error("error in getMonthlyPayslip");
            return new ResponseClass(e.getMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @ApiOperation(value = "Api to push into monthly payroll", notes = "push into the monthly payroll")
    @PostMapping("/insertPayslip")
    public ResponseClass insertMontlyPayslip(@RequestParam Integer employeeId, @RequestParam Integer payslipYear,@RequestParam Integer payslipMonth)
    {
        log.info("inside insertMonthlyPayslip employeeId {}, payslipYear {}, payslipMonth {} ",employeeId,payslipYear,payslipMonth);
        try{
            List<EmployeeMonthlyPayroll> pushedEmployeeMonthlyPayroll = employeeMonthlyPayrollService.insertMonthlyPayslip(employeeId,payslipYear,payslipMonth);
            log.info("Succesfully inserted monthly payslip");
            return new ResponseClass(pushedEmployeeMonthlyPayroll,"SUCCESS",HttpStatus.OK);
        }
        catch (Exception e){
            e.printStackTrace();
            log.error("error in getMonthlyPayslip");
            return new ResponseClass(e.getLocalizedMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }

    @ApiOperation(value = "Api to push into monthly payroll for all employees for given month and year",
            notes = "Insert into monthly payroll for all employees for given month and year")
    @PostMapping("/batchInsertPayslip")
    public ResponseClass batchPayslipInsertForMonthAndYear(@RequestParam Integer payslipYear,
                                                           @RequestParam Integer payslipMonth) throws Exception {
        try {
            log.info("REST Batch insertion payroll for month {} year {}", payslipMonth, payslipYear);

            employeeMonthlyPayrollService.batchPayslipInsertForMonthAndYear(payslipYear, payslipMonth);

            return new ResponseClass("Batch insertion for month " + payslipMonth
                    + " year " + payslipYear + " successful", "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Error batch fun failed for month {} year {}", payslipMonth, payslipYear);
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Error batch fun failed for month " + payslipMonth + " year " + payslipYear + "\n"
                    + e.getLocalizedMessage());
        }

    }
}
