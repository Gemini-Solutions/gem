package in.gemini.payroll.services;

import in.gemini.payroll.entity.InvestmentLimitXref;
import in.gemini.payroll.repository.InvestLimitXrefRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Transactional
@Service
public class InvestLimitXrefService {

    @Autowired
    private InvestLimitXrefRepo investLimitXrefRepo;

    private static final Logger log = LoggerFactory.getLogger(InvestLimitXrefService.class);

//    public InvestmentLimitXref addNewInvestLimitXref(InvestmentLimitXref investmentLimitXref) throws Exception {
//        log.info("Inside addNewInvestLimitXref service, data :"+investmentLimitXref);
//        Optional<InvestmentLimitXref> optionalInvestmentLimitXref = investLimitXrefRepo.findById(investmentLimitXref.getSection());
//        if(optionalInvestmentLimitXref.isPresent())
//        {
//            log.info(investmentLimitXref + " already exist in the InvestmentLimitXref Table");
//            throw new Exception(investmentLimitXref + " already exist in the InvestmentLimitXref Table");
//        }
//
//        investmentLimitXref.setRowUpdateBy(investmentLimitXref.getRowInsertBy());
//        investmentLimitXref.setRowInsertDate(new Date(System.currentTimeMillis()));
//        investmentLimitXref.setRowUpdateDate(new Date(System.currentTimeMillis()));
//
//        return investLimitXrefRepo.save(investmentLimitXref);
//    }
    public InvestmentLimitXref getInvestmentLimitXrefBySection(String section) throws Exception {

        Optional<InvestmentLimitXref> optionalInvestmentLimitXref = investLimitXrefRepo.findById(section);

        if (!optionalInvestmentLimitXref.isPresent()) {
            log.info(section + " does not exist in the InvestmentLimitXref Table");
            throw new Exception(section + " does not exist in the InvestmentLimitXref Table");
        }

        return optionalInvestmentLimitXref.get();
    }

    // Nov 24, 2021 return all Investment Limit Xrefs
    public List<InvestmentLimitXref> getAllInvestLimitXrefs() {
        log.info("service getAllInvestLimitXrefs");
        return investLimitXrefRepo.findAll();
    }
}
