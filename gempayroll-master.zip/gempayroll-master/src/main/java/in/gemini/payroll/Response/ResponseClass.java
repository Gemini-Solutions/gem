package in.gemini.payroll.Response;

import org.springframework.http.HttpStatus;

public class ResponseClass {

	Object data;
	String msg;
	HttpStatus statusCode;
	
	public ResponseClass() {

	}
	
	public ResponseClass(Object data, String msg, HttpStatus statusCode) {
		super();
		this.data = data;
		this.msg = msg;
		this.statusCode = statusCode;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public HttpStatus getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}

}
