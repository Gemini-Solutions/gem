package in.gemini.payroll.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PAYROLL_CALCULATION_VW", schema = "payroll")
public class PayrollCalc {

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public Integer getRownum() {
        return rownum;
    }

    public void setRownum(Integer rownum) {
        this.rownum = rownum;
    }

    @Column(name = "EMPLOYEE_ID")
    private Integer employeeId;

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }


    @Column(name = "COMPONENT")
    private String component;
    @Id
    @Column(name = "ROW_NUM")
    private Integer rownum;
    @Column(name = "VALUE")
    private Integer value;
}
