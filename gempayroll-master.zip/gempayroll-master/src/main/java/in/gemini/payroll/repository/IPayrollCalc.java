package in.gemini.payroll.repository;

import in.gemini.payroll.entity.PayrollCalc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IPayrollCalc extends JpaRepository<PayrollCalc,Integer> {
    List<PayrollCalc> findByemployeeId(Integer employeeId);

}
