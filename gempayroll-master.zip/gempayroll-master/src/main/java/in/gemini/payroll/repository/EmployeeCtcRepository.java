package in.gemini.payroll.repository;

import in.gemini.payroll.entity.EmployeeCtc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional
public interface EmployeeCtcRepository extends JpaRepository<EmployeeCtc,Long> {
    Optional<List<EmployeeCtc>> findByEmployeeId(Integer employeeId);
}
