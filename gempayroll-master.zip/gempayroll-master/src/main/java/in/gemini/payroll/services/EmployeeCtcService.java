package in.gemini.payroll.services;

import in.gemini.payroll.entity.EmployeeDeductions;
import in.gemini.payroll.entity.EmployeeDetails;
import in.gemini.payroll.entity.EmployeeCtc;
import in.gemini.payroll.repository.CtcRepository;
import in.gemini.payroll.repository.EmployeeDeductionsRepository;
import in.gemini.payroll.repository.EmployeeDetailsRepository;
import in.gemini.payroll.repository.EmployeeCtcRepository;

import in.gemini.payroll.utility.Constants;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class EmployeeCtcService {
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    private EmployeeCtcRepository employeeCtcRepository;
    @Autowired
    private CtcRepository ctcRepository;
    @Autowired
    private EmployeeDetailsRepository employeeDetailsRepository;
    @Autowired
    private EmployeeDeductionsRepository employeeDeductionsRepository;

    private static final Logger log = LoggerFactory.getLogger(EmployeeCtcService.class);

    public List<EmployeeCtc> addEmployeeCtcService(List<EmployeeCtc> employeeCtc) throws Exception {
        log.info("Inside add employee ctc service - " + employeeCtc.toString());

//        //if ctc_component exists or not (foreign key dependency)
//        if(!ctcRepository.existsById(employeeCtc.getCtcComponent()))
//        {
//            log.info("CTC component : "+employeeCtc.getCtcComponent() + " does not exist");
//            throw new Exception("CTC component : "+employeeCtc.getCtcComponent() + " does not exist");
//        }
//
//        Optional<EmployeeDetails> employeeDetails = employeeDetailsRepository.findById(employeeCtc.getEmployeeId());
//        //if employee does not exist is employee_details table
//        if(!employeeDetails.isPresent())
//        {
//            log.info("Employee with id: "+employeeCtc.getEmployeeId() + " does not exist");
//            throw new Exception("Employee with id: "+employeeCtc.getEmployeeId() + " does not exist");
//        }
//
//        //Avoiding any injection using ctc_id
//        if(employeeCtc.getEmployeeCtcId()!=null)
//        {
//            log.info("Employee ctc id is auto generated, don't push 'Employee ctc id' while creating");
//            throw new Exception("Employee ctc id is auto generated, don't push 'Employee ctc id' while creating");
//        }
//
//        employeeCtc.setRowUpdateBy(employeeCtc.getRowInsertBy());
//        employeeCtc.setRowInsertDate(getTime());
//        employeeCtc.setRowUpdateDate(getTime());
        // TODO change filter conditions to accommodate all components. But also need tax saving and investment components too.
        //  For now using salary components Excel for components for easy insertion.
        List<EmployeeDeductions> employeeDeductionsList = employeeCtc.stream().
                filter(e->("PF,PAYTM").contains(e.getCtcComponent()))
                .map    (e->modelMapper.map(e,EmployeeDeductions.class))
                .collect(Collectors.toList());

        List<EmployeeCtc> employeeCtcList = employeeCtc.stream()
                .filter(e-> Constants.salaryComponentsForExcel.containsValue(e.getCtcComponent()))
                .map(e->modelMapper.map(e,EmployeeCtc.class))
                .collect(Collectors.toList());

        List<EmployeeCtc> employeeCtcResponse = employeeCtcRepository.saveAll(employeeCtcList);
        employeeDeductionsRepository.saveAll(employeeDeductionsList);
        return employeeCtcResponse;
    }


    //get all employee_ctc
    @Transactional(readOnly = true)
    public List<EmployeeCtc> getAllEmployeeCtcService() throws Exception {
        log.info("Inside get all Employee Ctc service");

        List<EmployeeCtc> employeeCtcList = new ArrayList<>();
            employeeCtcList = employeeCtcRepository.findAll();
        if(employeeCtcList.isEmpty())
        {
            log.info("No employee ctc list found");
            throw new Exception("No data found");
        }
        return employeeCtcList;
    }


    //get employee_ctc by employee id
    @Transactional(readOnly = true)
    public List<EmployeeCtc> getEmployeeCtcByIdService(Integer employeeId) throws Exception {
        log.info("Inside get Employee Ctc Service, id : "+employeeId);
        if(!employeeDetailsRepository.findById(employeeId).isPresent())
        {
            log.info("No employee details found for Id: "+employeeId);
        }

        Optional<List<EmployeeCtc>>employee_ctc_list = employeeCtcRepository.findByEmployeeId(employeeId);
        if(!employee_ctc_list.isPresent()){
            log.info("NO employee ctc found with employee id : "+employeeId);
            throw new Exception("NO employee ctc found with employee id : "+employeeId);
        }
        return employee_ctc_list.get();
    }

    //delete function
    public void deleteEmployeeCtcByIdService(Long employeeCtcId) throws Exception {
        log.info("Inside delete Employee Ctc By Id Service , id : "+employeeCtcId);

        Optional<EmployeeCtc> employee_ctc = employeeCtcRepository.findById(employeeCtcId);
        if(!employee_ctc.isPresent())
        {
            log.info("NO employee ctc found with employee id : "+employeeCtcId);
            throw new Exception("NO employee ctc found with employee id : "+employeeCtcId);
        }
        employeeCtcRepository.deleteById(employeeCtcId);
    }

    //update function
    public void updateEmployeeCtcService(EmployeeCtc employeeCtc) throws Exception {
        log.info("Inside Update Employee CTC service, data :"+employeeCtc);

        //checking if the given ctc component exists or not
        if(!ctcRepository.existsById(employeeCtc.getCtcComponent()))
        {
            log.info("CTC component : "+employeeCtc.getCtcComponent() + " does not exist");
            throw new Exception("CTC component : "+employeeCtc.getCtcComponent() + " does not exist");
        }
        //checking if the given employee id exist or not
        if(!employeeDetailsRepository.findById(employeeCtc.getEmployeeId()).isPresent())
        {
            log.info("Employee does not exist with id :"+employeeCtc.getEmployeeId());
            throw new Exception("Employee does not exist with id :"+employeeCtc.getEmployeeId());
        }

        //getting the employee ctc from database
        Optional<EmployeeCtc> optionalEmployee_ctc = employeeCtcRepository.findById(employeeCtc.getEmployeeCtcId());
        if(!optionalEmployee_ctc.isPresent())
        {
            log.info("No employee ctc found for with employee_ctc_id : "+employeeCtc.getEmployeeCtcId());
            throw new Exception("No employee ctc found for with employee_ctc_id : "+employeeCtc.getEmployeeCtcId());
        }

        //employee_ctc_id,row_inserted_by,row_inserted_date columns are not updated
        optionalEmployee_ctc.get().setEmployeeId(employeeCtc.getEmployeeId());
        optionalEmployee_ctc.get().setCtcComponent(employeeCtc.getCtcComponent());
        optionalEmployee_ctc.get().setAmount(employeeCtc.getAmount());
        optionalEmployee_ctc.get().setNotes(employeeCtc.getNotes());
        optionalEmployee_ctc.get().setFiscal(employeeCtc.getFiscal());
        optionalEmployee_ctc.get().setRowUpdateBy(employeeCtc.getRowUpdateBy());
        optionalEmployee_ctc.get().setStatus(employeeCtc.getStatus());
        optionalEmployee_ctc.get().setRowUpdateDate(getTime());
        employeeCtcRepository.save(optionalEmployee_ctc.get());

    }

    //getting the employee ctc details by using employee ctc id
    @Transactional(readOnly = true)
    public EmployeeCtc getEmployeeCtcByCtcIdService(Long employeeCtcId) throws Exception {
        log.info("Inside get Employee Ctc by ctc id Service, id :"+employeeCtcId);

        Optional<EmployeeCtc>employeeCtc = employeeCtcRepository.findById(employeeCtcId);
        if(!employeeCtc.isPresent()){
            log.info("NO employee ctc found with employeeCtcId : "+employeeCtcId);
            throw new Exception("NO employee ctc found with employeeCtcId : "+employeeCtcId);
        }
        return employeeCtc.get();
    }

    //returns the time
    private Date getTime()
    {
        return new Date(System.currentTimeMillis());
    }

}
