package in.gemini.payroll.Response;


public class GrossAndCTCPlaceHolder {
    public GrossAndCTCPlaceHolder(String ctcComponent, Integer amount) {
        this.ctcComponent = ctcComponent;
        this.amount = amount;
    }

    public String getCtcComponent() {
        return ctcComponent;
    }

    public void setCtcComponent(String ctcComponent) {
        this.ctcComponent = ctcComponent;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    private String ctcComponent;
    private Integer amount;

}
