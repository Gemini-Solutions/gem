package in.gemini.payroll.repository;

import in.gemini.payroll.entity.InvestmentViaXref;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InvestViaXrefRepo extends JpaRepository<InvestmentViaXref, Long> {

    Optional<InvestmentViaXref> findBySectionAndInvestmentType(String section,String investmentType);
    List<InvestmentViaXref> findBySection(String section);
}
