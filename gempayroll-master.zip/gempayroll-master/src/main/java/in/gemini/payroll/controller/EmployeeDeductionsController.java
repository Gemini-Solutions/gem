package in.gemini.payroll.controller;

import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.EmployeeDeductions;
import in.gemini.payroll.services.EmployeeDeductionService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/employee-deductions")
public class EmployeeDeductionsController {

    @Autowired
    private EmployeeDeductionService employeeDeductionService;

    private static final Logger log = LoggerFactory.getLogger(EmployeeDeductionsController.class);

    @PostMapping("/createEmpDeduction")
    @ApiOperation(value = "Add Employee's new Deduction", notes = "Create an existing employee's new deduction type that exists in deduction xref. " +
            "Pass rowUpdateBy same as rowInsertBy")
    public ResponseClass createEmployeeDeductions(@RequestBody EmployeeDeductions employeeDeductions) {
//        log.info("REST create employee deduction {} ", employeeDeductions.toString());
        log.info("REST create employee deduction {} ", employeeDeductions);
        try {
            EmployeeDeductions response = employeeDeductionService.createEmployeeDeductions(employeeDeductions);
            log.info("REST create employee deduction response {} ", response);

            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST createEmployeeDeductions error {}", e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping("/getAllEmpDeductions")
    @ApiOperation(value = "Get all employees all deductions")
    public ResponseClass getAllEmpDeductions() {
        log.info("REST getEmpAllDeductions");
        try {
            List<EmployeeDeductions> response = employeeDeductionService.getAllEmployeesDeductions();
            log.info("REST getAllEmpDeductions end with size {}", response.size());
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST getEmpDeductions could not load data {}", e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    @GetMapping("/getEmpDeduction/{employeeId}/{deduction}")
    @ApiOperation(value = "get a particular employee's particular deduction", notes = "employeeId/deduction in url request.")
    public ResponseClass getEmpDeductionByEmpIdAndDeduction(@PathVariable("employeeId") Integer employeeId, @PathVariable("deduction") String deduction) {
        log.info("REST get employee deduction by emp id {} and deduction {}", employeeId, deduction);
        try {
            EmployeeDeductions response = employeeDeductionService.getEmpDeductionByEmpIdAndDeduction(employeeId, deduction);
            log.info("REST get employee deduction end {}", response);
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST getEmpDeductionByEmpIdAndDeduction error {}", e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PutMapping("/updateEmpDeduction")
    @ApiOperation(value = "update an employee's deduction", notes = "Pass whole whole object as JSON to update all details")
    public ResponseClass updateEmpDeduction(@RequestBody EmployeeDeductions employeeDeductions) {
        log.info("REST update Employee deduction {}", employeeDeductions);

        try {
            EmployeeDeductions response = employeeDeductionService.updateEmployeeDeduction(employeeDeductions);
            log.info("REST updateEmpDeduction end");
            return new ResponseClass(response, "SUCCESS", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST update Employee Deduction Error: {}", e.getMessage());
            return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deleteEmpDeductionByEmpIdDeduction/{employeeId}/{deduction}")
    @ApiOperation(value = "delete employee's deduction", notes = "Delete by providing employeeId and deduction string")
    public ResponseClass deleteEmpDeductionByEmployeeIdAndDeduction(@PathVariable("employeeId") Integer employeeId, @PathVariable("deduction") String deduction) {
        log.info("REST delete employee deduction by employeeId {} and Deduction {}", employeeId, deduction);
        try {
            employeeDeductionService.deleteEmployeeDeductionByEmployeeIdAndDeduction(employeeId, deduction);
            log.info("REST deleteEmployeeDeductionByEmployeeIdAndDeduction emp id {} and deduction {} end", employeeId, deduction);
            return new ResponseClass("EmployeeId " + employeeId + "  with deduction " + deduction + " deletion successful", "SUCCESS", HttpStatus.OK);

        } catch (Exception e) {
            e.printStackTrace();
            log.error("REST deleteEmpDeductionByEmployeeIdAndDeduction error {}", e.getMessage());
            return new ResponseClass("employee deduction deletion fail " + e.getMessage(), "FAIL", HttpStatus.OK);
        }
    }
}
