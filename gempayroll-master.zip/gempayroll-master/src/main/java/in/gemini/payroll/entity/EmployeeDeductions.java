package in.gemini.payroll.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "EMPLOYEE_DEDUCTIONS", schema = "payroll")
public class EmployeeDeductions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EMP_DEDUCTION_ID")
    private Long empDeductionId;

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    @Column(name = "EMPLOYEE_ID")
    private Integer employeeId;

    @Column(name = "DEDUCTION")
    private String deduction;

    @Column(name = "AMOUNT")
    private Integer amount;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "FISCAL")
    private String fiscal;

    @Column(name = "ROW_INSERT_BY")
    String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "31/12/2020 23:59:59")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss", timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE")
    Date rowInsertDate;

    @Column(name = "ROW_UPDATE_BY")
    String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "31/12/2020 23:59:59")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss", timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE")
    Date rowUpdateDate;

    public Long getEmpDeductionId() {
        return empDeductionId;
    }

    public void setEmpDeductionId(Long empDeductionId) {
        this.empDeductionId = empDeductionId;
    }

    public String getDeduction() {
        return deduction;
    }

    public void setDeduction(String deduction) {
        this.deduction = deduction;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFiscal() {
        return fiscal;
    }

    public void setFiscal(String fiscal) {
        this.fiscal = fiscal;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    @Override
    public String toString() {
        return "EmployeeDeductions{" +
                "empDeductionId=" + empDeductionId +
                ", employeeId='" + employeeId + '\'' +
                ", deduction='" + deduction + '\'' +
                ", amount=" + amount +
                ", status='" + status + '\'' +
                ", fiscal='" + fiscal + '\'' +
                ", rowInsertBy='" + rowInsertBy + '\'' +
                ", rowInsertDate=" + rowInsertDate +
                ", rowUpdateBy='" + rowUpdateBy + '\'' +
                ", rowUpdateDate=" + rowUpdateDate +
                '}';
    }
}
