package in.gemini.payroll.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.CtcStructure;
import in.gemini.payroll.services.CtcService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/ctc")
public class CtcController {
	
	@Autowired
	private CtcService ctcService;
	
	private static final Logger log = LoggerFactory.getLogger(CtcController.class);
	
	@ApiOperation(value = "API to add ctc component", notes="Add ctc component into database")
	@PostMapping("/addCtcComponent")
	public ResponseClass addCtcComponent(@RequestBody CtcStructure ctcStructure){
		log.info("Inside Add ctc component - " + ctcStructure.getCtcComponent());
		try {
			CtcStructure ctcResponse = ctcService.addCtcComponentService(ctcStructure);
			log.info("completed adding ctc component - " + ctcStructure.getCtcComponent());
			return new ResponseClass(ctcResponse, "SUCESS", HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Error in adding ctc component - " + ctcStructure.getCtcComponent());
			return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "API to get all CTC component", notes="Get all ctc component details")
	@GetMapping("/allCtcComponent")
	public ResponseClass getAllCtcComponent(){
		log.info("Inside get all ctc component");
		List<CtcStructure> ctcList = null;
		try {
			ctcList = ctcService.getAllCtcComponentService();
			log.info("Successfully get all ctc component");
			return new ResponseClass(ctcList, "SUCESS", HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Error in get all ctc component");
			return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "API to get CTC component detail by ctc Component", notes="Get a ctc component detail by ctc component name")
	@GetMapping("/getCtcComponentDetail")
	public ResponseClass getCtcComponentDetail(@RequestParam String ctcComponent){
		log.info("Inside get ctc component detail - " + ctcComponent);
		CtcStructure ctc = null;
		try {
			ctc = ctcService.getCtcComponentService(ctcComponent);
			log.info("Successfully get ctc component detail - " + ctc.toString());
			return new ResponseClass(ctc, "SUCESS", HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Error in get ctc component detail - " + ctcComponent);
			return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "API to delete a CTC component", notes="Delete a ctc component detail from database by ctc component name")
	@DeleteMapping("/deleteCtcComponent")
	public ResponseClass deleteCtcComponent(@RequestParam String ctcComponent){
		log.info("Inside delete ctc component - " + ctcComponent);
		try {
			ctcService.deleteCtcComponentService(ctcComponent);
			log.info("Successfully deleted ctc component - " + ctcComponent);
			return new ResponseClass("CTC component deleted successfully", "SUCESS", HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Error in deleting ctc component - " + ctcComponent);
			return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@ApiOperation(value = "API to update a CTC component", notes="update an existing ctc component detail into database")
	@PutMapping("/updateCtcComponent")
	public ResponseClass updateCtcComponent(@RequestBody CtcStructure ctcStructure){
		log.info("Inside update ctc component - " + ctcStructure.getCtcComponent());
		try {
			ctcService.updateCtcComponentService(ctcStructure);
			log.info("Successfully updated ctc component - " + ctcStructure.getCtcComponent());
			return new ResponseClass("CTC component updated successfully", "SUCESS", HttpStatus.OK);
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Error in updating ctc component - " + ctcStructure.getCtcComponent());
			return new ResponseClass(e.getMessage(), "FAIL", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
