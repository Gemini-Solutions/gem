package in.gemini.payroll.repository;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import in.gemini.payroll.entity.*;

@Repository
@Transactional
public interface CtcRepository extends CrudRepository<CtcStructure, String>{
	
//	CtcStructure findByCtcComponent(String ctcComponent);
//	
//	int deleteByCtcComponent(String ctcComponent);
}
