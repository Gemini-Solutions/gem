package in.gemini.payroll.services;

import in.gemini.payroll.entity.InvestmentViaXref;
import in.gemini.payroll.entity.PayrollOptions;
import in.gemini.payroll.repository.IOptionsRepository;
import in.gemini.payroll.repository.InvestViaXrefRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OptionService {
    @Autowired
    IOptionsRepository iOptionsRepository;
    @Autowired
    InvestViaXrefRepo investViaXrefRepo;


    public List<PayrollOptions> getPayrollOptions(String key)
    {
        return iOptionsRepository.findByoptionKey(key);
    }

    public List<InvestmentViaXref> getInvestmentOptions(String section)
    {
        return investViaXrefRepo.findBySection(section);
    }
}
