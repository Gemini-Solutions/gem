package in.gemini.payroll.services;

import org.springframework.validation.annotation.Validated;


public class Validator {
    public Validator() {
    }

    public Boolean isNameValid(String fullName){
        String regex = ".*";
        return fullName.matches(regex);
    }
}
