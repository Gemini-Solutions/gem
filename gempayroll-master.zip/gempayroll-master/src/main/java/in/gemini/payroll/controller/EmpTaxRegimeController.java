package in.gemini.payroll.controller;


import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.entity.EmpTaxRegime;
import in.gemini.payroll.services.EmpTaxRegimeService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/EmpTaxRegime")
public class EmpTaxRegimeController {

    @Autowired
    private EmpTaxRegimeService empTaxRegimeService;

    private static final Logger log = LoggerFactory.getLogger(EmpTaxRegimeController.class);

    @PostMapping("/addEmpTaxRegime")
    @ApiOperation(value = "API to add Employee Tax Regime in payroll database")
    public ResponseClass addEmpTaxRegime(@RequestBody EmpTaxRegime empTaxRegime)
    {
        log.info("Inside the Add Employee Tax Regime , data :"+empTaxRegime);
        try {
            EmpTaxRegime response = empTaxRegimeService.addEmpTaxRegime(empTaxRegime);
            log.info("Successfully added an employee tax regime for data :"+empTaxRegime);
            return new ResponseClass(response,"SUCCESS" ,HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            log.error("Error in adding the employee tax regime data for :- "+empTaxRegime.toString()
            +"\n Exception : "+e);
            return new ResponseClass(e.getMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/getAllEmpTaxRegime")
    @ApiOperation(value = "API to get all the employee tax regime")
    public ResponseClass getALlEmpTaxRegime()
    {
        log.info("Inside getALlEmpTaxRegime controller");
        try {
            List<EmpTaxRegime> response = empTaxRegimeService.getALlEmpTaxRegime();
            log.info("Successfully fetched all the employee Tax Regime data");
            return new ResponseClass(response,"SUCCESS",HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            log.error("Error in getting the employee tax regime "+
                    "\nException :"+e);
            return new ResponseClass(e.getMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    @GetMapping("/getEmpTaxRegimeById")
    @ApiOperation(value = "API to get the employee Tax regime by tax regime id")
    public ResponseClass getEmpTaxRegimeById(@RequestParam Long empTaxRegimeId)
    {
        log.info("Inside the get employee tax regime by id :"+empTaxRegimeId);
        try {
            EmpTaxRegime response = empTaxRegimeService.getEmpTaxRegimeById(empTaxRegimeId);
            log.info("Successfully fetched the Employee Tax Regime data for id :"+empTaxRegimeId);
            return new ResponseClass(response,"SUCCESS",HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            log.error("Error in getting the employee tax regime with id : "+empTaxRegimeId+
                    "\nException :"+e);
            return new ResponseClass(e.getMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to get the employee tax regimes list by employee id")
    @GetMapping("/getEmpTaxRegimeByEmpId")
    public ResponseClass getEmpTaxRegimeByEmpId(@RequestParam Integer employeeId)
    {
        log.info("Inside the get employee tax regimes list by employee id :"+employeeId);
        try{
            List<EmpTaxRegime> response = new ArrayList<>();
            response = empTaxRegimeService.getEmpTaxRegimeByEmpId(employeeId);
            log.info("Successfully fetched Employee Tax Regime List using the employee id: "+employeeId);
            return new ResponseClass(response,"SUCCESS",HttpStatus.OK);
        }catch (Exception e)
        {
            e.printStackTrace();
            log.error("Error in fetching Employee Tax Regime List using the employee id: "+employeeId+
                    "\nException :"+e);
            return new ResponseClass(e.getMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "API to update the employee tax regime")
    @PutMapping("/updateEmpTaxRegime")
    public ResponseClass updateEmpTaxRegime(@RequestBody EmpTaxRegime empTaxRegime)
    {
        log.info("Inside Update Employee Tax Regime ,data : "+empTaxRegime);
        try {
            empTaxRegimeService.updateEmpTaxRegime(empTaxRegime);
            log.info("Successfully updated the employee tax regime, data:"+empTaxRegime);
            return new ResponseClass("Updated the Employee Tax Regime","SUCCESS",HttpStatus.OK);
        }catch (Exception e){
            e.printStackTrace();
            log.error("Error in updating the employee tax regime,data : "+empTaxRegime+
                    "\n Exception : "+e);
            return new ResponseClass(e.getMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiOperation(value = "Api to delete the employee tax regime by empTaxRegimeId")
    @DeleteMapping("/deleteEmpTaxRegime")
    public ResponseClass deleteEmpTaxRegime(@RequestParam Long empTaxRegimeId)
    {
        log.info("Inside the delete Employee Tax Regime,data : "+empTaxRegimeId);
        try {
            empTaxRegimeService.deleteEmpTaxRegime(empTaxRegimeId);
            log.info("Successfully deleted the employee tax regime for id :"+empTaxRegimeId);
            return new ResponseClass("Successfully deleted the employee tax regime","SUCCESS",HttpStatus.OK);
        }catch (Exception e){
            e.printStackTrace();
            log.error("Error in Deleting the employee tax regime, data : "+empTaxRegimeId+
                    "\nException :"+e);
            return new ResponseClass(e.getMessage(),"FAIL",HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
