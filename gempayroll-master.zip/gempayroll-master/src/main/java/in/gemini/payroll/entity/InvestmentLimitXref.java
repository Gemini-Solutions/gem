package in.gemini.payroll.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="INVESTMENT_LIMIT_XREF", schema = "payroll")
@JsonIgnoreProperties(ignoreUnknown = true)
public class InvestmentLimitXref {
    @Id
    @Column(name = "SECTION")
    private String section;

    @Column(name = "INVESTMENT_LIMIT")
    private Integer investmentLimit;

    @Column(name = "ROW_INSERT_BY")
    private String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss", timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE")
    private Date rowInsertDate;

    @Column(name = "ROW_UPDATE_BY")
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss", timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE")
    private Date rowUpdateDate;


    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public Integer getInvestmentLimit() {
        return investmentLimit;
    }

    public void setInvestmentLimit(Integer investmentLimit) {
        this.investmentLimit = investmentLimit;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    @Override
    public String toString() {
        return "InvestmentLimitXref{" +
                "section='" + section + '\'' +
                ", investmentLimit=" + investmentLimit +
                ", rowInsertBy='" + rowInsertBy + '\'' +
                ", rowInsertDate=" + rowInsertDate +
                ", rowUpdateBy='" + rowUpdateBy + '\'' +
                ", rowUpdateDate=" + rowUpdateDate +
                '}';
    }
}
