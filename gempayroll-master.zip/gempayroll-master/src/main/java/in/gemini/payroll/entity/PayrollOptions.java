package in.gemini.payroll.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "PAYROLL_OPTIONS" , schema = "payroll")
public class PayrollOptions {
    @Id
    @Column(name = "OPTION_ID")
    private Integer optionId;
    @Column(name = "OPTION_KEY")
    private String optionKey;
    @Column(name = "OPTION_VALUE")
    private String optionValue;

    public String getOptionName() {
        return optionName;
    }

    public void setOptionName(String optionName) {
        this.optionName = optionName;
    }

    @Column(name = "OPTION_NAME")
    private String optionName;
    @Column(name = "OPTION_DESCRIPTION")
    private String optionDesc;

    @Column(name="ROW_INSERT_BY",nullable = false)
    private String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE",nullable = false)
    private Date rowInsertDate;

    public Integer getOptionId() {
        return optionId;
    }

    public void setOptionId(Integer optionId) {
        this.optionId = optionId;
    }

    public String getOptionKey() {
        return optionKey;
    }

    public void setOptionKey(String optionKey) {
        this.optionKey = optionKey;
    }

    public String getOptionValue() {
        return optionValue;
    }

    public void setOptionValue(String optionValue) {
        this.optionValue = optionValue;
    }

    public String getOptionDesc() {
        return optionDesc;
    }

    public void setOptionDesc(String optionDesc) {
        this.optionDesc = optionDesc;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    @Column(name = "ROW_UPDATE_BY",nullable = false)
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE",nullable = false)
    private Date rowUpdateDate;

}
