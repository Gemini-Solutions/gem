package in.gemini.payroll.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "DEDUCTIONS_XREF", schema = "payroll")
public class DeductionsXref {

    @Id
    @Column(name = "DEDUCTION")
    private String deduction;

    @Column(name = "DEDUCTION_LIMIT")
    private Integer deductionLimit;

    @Column(name = "ROW_INSERT_BY")
    String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "31/12/2020 23:59:59")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE")
    Date rowInsertDate;

    @Column(name = "ROW_UPDATE_BY")
    String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "31/12/2020 23:59:59")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE")
    Date rowUpdateDate;

    public String getDeduction() {
        return deduction;
    }

    public void setDeduction(String deduction) {
        this.deduction = deduction;
    }

    public Integer getDeductionLimit() {
        return deductionLimit;
    }

    public void setDeductionLimit(Integer deductionLimit) {
        this.deductionLimit = deductionLimit;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }
}
