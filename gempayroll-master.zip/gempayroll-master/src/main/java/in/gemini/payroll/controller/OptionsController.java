package in.gemini.payroll.controller;

import in.gemini.payroll.Response.ResponseClass;
import in.gemini.payroll.services.OptionService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/options")
public class OptionsController {

    @Autowired
    OptionService optionService;

    @GetMapping("/{key}")
    @ApiOperation(value = "Get option/dropdown for payroll basis key")
    public ResponseClass getPayrollOptions(@PathVariable(value = "key") String key)
    {
        return new ResponseClass(optionService.getPayrollOptions(key),
                "SUCCESS", HttpStatus.OK);
    }

    @GetMapping("/investment/{section}")
    @ApiOperation(value = "Get option/dropdown for invstment declaration basis key")
    public ResponseClass getInvestmentDeclarationOptions(@PathVariable(value = "section") String section)
    {
        return new ResponseClass(optionService.getInvestmentOptions(section),
                "SUCCESS", HttpStatus.OK);
    }
}


