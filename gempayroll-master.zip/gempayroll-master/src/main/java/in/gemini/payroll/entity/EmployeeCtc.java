package in.gemini.payroll.entity;



import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name="EMPLOYEE_CTC", schema = "payroll")
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmployeeCtc {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EMP_CTC_ID")
    private Long employeeCtcId;

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    @Column(name = "EMPLOYEE_ID")
    private Integer employeeId;

    @Column(name="CTC_COMPONENT")
    private String ctcComponent;

    @Column(name = "AMOUNT")
    private Integer amount;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "FISCAL")
    private String fiscal;
    @Column(name = "NOTES")
    private String notes;
    @Column(name = "ROW_INSERT_BY")
    private String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE")
    private Date rowInsertDate;

    @Column(name = "ROW_UPDATE_BY")
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE")
    private Date rowUpdateDate;


    public Long getEmployeeCtcId() {
        return employeeCtcId;
    }

    public void setEmployeeCtcId(Long employeeCtcId) {
        this.employeeCtcId = employeeCtcId;
    }


    public String getCtcComponent() {
        return ctcComponent;
    }

    public void setCtcComponent(String ctcComponent) {
        this.ctcComponent = ctcComponent;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFiscal() {
        return fiscal;
    }

    public void setFiscal(String fiscal) {
        this.fiscal = fiscal;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    @Override
    public String toString() {
        return "EmployeeCtc{" +
                "employeeCtcId=" + employeeCtcId +
                ", employeeId='" + employeeId + '\'' +
                ", ctcComponent='" + ctcComponent + '\'' +
                ", amount=" + amount +
                ", status='" + status + '\'' +
                ", fiscal='" + fiscal + '\'' +
                ", notes='" + notes + '\'' +
                ", rowInsertBy='" + rowInsertBy + '\'' +
                ", rowInsertDate=" + rowInsertDate +
                ", rowUpdateBy='" + rowUpdateBy + '\'' +
                ", rowUpdateDate=" + rowUpdateDate +
                '}';
    }
}