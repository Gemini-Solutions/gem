package in.gemini.payroll.entity;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="IT_SLAB", schema = "payroll")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ItSlab {
    @Id
    @Column(name = "IT_SLAB_ID")
    private Long itSlabId;

    @Column(name = "LOWER_BOUND",nullable = false)
    private Integer lowerBound;

    @Column(name = "UPPER_BOUND",nullable = false)
    private Integer upperBound;

    @Column(name = "TAX_REGIME_TYPE",nullable = false)
    private String taxRegimeType;

    @Column(name = "TAX_RATE",nullable = false)
    private Integer taxRate;
    @Column(name = "STATUS",nullable = false)
    private String status;
    @Column(name = "NOTES")
    private String notes;
    @Column(name="ROW_INSERT_BY",nullable = false)
    private String rowInsertBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_INSERT_DATE",nullable = false)
    private Date rowInsertDate;

    @Column(name = "ROW_UPDATE_BY",nullable = false)
    private String rowUpdateBy;

    @ApiModelProperty(value = "Date as string", example = "20/12/2020 20:20:20")
    @JsonFormat(pattern = "dd/MM/yyyy hh:mm:ss",timezone = "Asia/Kolkata")
    @Column(name = "ROW_UPDATE_DATE",nullable = false)
    private Date rowUpdateDate;


    public Long getItSlabId() {
        return itSlabId;
    }

    public void setItSlabId(Long itSlabId) {
        this.itSlabId = itSlabId;
    }

    public Integer getLowerBound() {
        return lowerBound;
    }

    public void setLowerBound(Integer lowerBound) {
        this.lowerBound = lowerBound;
    }

    public Integer getUpperBound() {
        return upperBound;
    }

    public void setUpperBound(Integer upperBound) {
        this.upperBound = upperBound;
    }

    public String getTaxRegimeType() {
        return taxRegimeType;
    }

    public void setTaxRegimeType(String taxRegimeType) {
        this.taxRegimeType = taxRegimeType;
    }

    public Integer getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(Integer taxRate) {
        this.taxRate = taxRate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getRowInsertBy() {
        return rowInsertBy;
    }

    public void setRowInsertBy(String rowInsertBy) {
        this.rowInsertBy = rowInsertBy;
    }

    public Date getRowInsertDate() {
        return rowInsertDate;
    }

    public void setRowInsertDate(Date rowInsertDate) {
        this.rowInsertDate = rowInsertDate;
    }

    public String getRowUpdateBy() {
        return rowUpdateBy;
    }

    public void setRowUpdateBy(String rowUpdateBy) {
        this.rowUpdateBy = rowUpdateBy;
    }

    public Date getRowUpdateDate() {
        return rowUpdateDate;
    }

    public void setRowUpdateDate(Date rowUpdateDate) {
        this.rowUpdateDate = rowUpdateDate;
    }

    @Override
    public String toString() {
        return "ItSlab{" +
                "itSlabId=" + itSlabId +
                ", lowerBound=" + lowerBound +
                ", upperBound=" + upperBound +
                ", taxRegimeType='" + taxRegimeType + '\'' +
                ", taxRate=" + taxRate +
                ", status='" + status + '\'' +
                ", notes='" + notes + '\'' +
                ", rowInsertBy='" + rowInsertBy + '\'' +
                ", rowInsertDate=" + rowInsertDate +
                ", rowUpdateBy='" + rowUpdateBy + '\'' +
                ", rowUpdateDate=" + rowUpdateDate +
                '}';
    }
}
