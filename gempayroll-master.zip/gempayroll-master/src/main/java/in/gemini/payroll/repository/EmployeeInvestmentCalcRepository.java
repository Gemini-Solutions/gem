package in.gemini.payroll.repository;

import in.gemini.payroll.entity.EmployeeInvestmentCalc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeInvestmentCalcRepository extends JpaRepository<EmployeeInvestmentCalc,Long> {

}