--
-- PostgreSQL database dump
--

-- Dumped from database version 10.15 (Ubuntu 10.15-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.15 (Ubuntu 10.15-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ctc_structure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ctc_structure (
    ctc_component character varying(50) NOT NULL,
    type character varying(10) NOT NULL,
    taxable character(1) NOT NULL,
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.ctc_structure OWNER TO postgres;

--
-- Name: deductions_xref; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deductions_xref (
    deduction character varying(20) NOT NULL,
    deduction_limit integer NOT NULL,
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.deductions_xref OWNER TO postgres;

--
-- Name: employee_ctc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_ctc (
    emp_ctc_id integer NOT NULL,
    employee_id character varying(10),
    ctc_component character varying(50),
    amount integer NOT NULL,
    status character varying(10) NOT NULL,
    fiscal character(4) NOT NULL,
    notes character varying(100),
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.employee_ctc OWNER TO postgres;

--
-- Name: employee_ctc_emp_ctc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_ctc_emp_ctc_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_ctc_emp_ctc_id_seq OWNER TO postgres;

--
-- Name: employee_ctc_emp_ctc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_ctc_emp_ctc_id_seq OWNED BY public.employee_ctc.emp_ctc_id;


--
-- Name: employee_deductions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_deductions (
    emp_deduction_id integer NOT NULL,
    employee_id character varying(10),
    deduction character varying(20),
    amount integer NOT NULL,
    status character varying(10) NOT NULL,
    fiscal character(4) NOT NULL,
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.employee_deductions OWNER TO postgres;

--
-- Name: employee_deductions_emp_deduction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_deductions_emp_deduction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_deductions_emp_deduction_id_seq OWNER TO postgres;

--
-- Name: employee_deductions_emp_deduction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_deductions_emp_deduction_id_seq OWNED BY public.employee_deductions.emp_deduction_id;


--
-- Name: employee_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_details (
    employee_id character varying(10) NOT NULL,
    emp_fname character varying(20) NOT NULL,
    emp_lname character varying(20) NOT NULL,
    status character varying(9) NOT NULL,
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL,
    residential_address character varying(100),
    city_type character(1)
);


ALTER TABLE public.employee_details OWNER TO postgres;

--
-- Name: employee_investment_declaration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_investment_declaration (
    emp_invest_decl_id integer NOT NULL,
    employee_id character varying(10) NOT NULL,
    section character varying(10),
    investment_type character varying(50),
    amount integer NOT NULL,
    fiscal character(4) NOT NULL,
    status character varying(9) NOT NULL,
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.employee_investment_declaration OWNER TO postgres;

--
-- Name: employee_investment_declaration_emp_invest_decl_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_investment_declaration_emp_invest_decl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_investment_declaration_emp_invest_decl_id_seq OWNER TO postgres;

--
-- Name: employee_investment_declaration_emp_invest_decl_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_investment_declaration_emp_invest_decl_id_seq OWNED BY public.employee_investment_declaration.emp_invest_decl_id;


--
-- Name: employee_investment_proof; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_investment_proof (
    emp_invest_proof_id integer NOT NULL,
    emp_invest_decl_id integer,
    proof_1 character varying(500) NOT NULL,
    proof_2 character varying(500),
    proof_3 character varying(500),
    status character varying(10) NOT NULL,
    notes character varying(100),
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.employee_investment_proof OWNER TO postgres;

--
-- Name: employee_investment_proof_emp_invest_proof_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_investment_proof_emp_invest_proof_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_investment_proof_emp_invest_proof_id_seq OWNER TO postgres;

--
-- Name: employee_investment_proof_emp_invest_proof_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_investment_proof_emp_invest_proof_id_seq OWNED BY public.employee_investment_proof.emp_invest_proof_id;


--
-- Name: employee_tax_regime; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_tax_regime (
    emp_tax_regime_id integer NOT NULL,
    employee_id character varying(10),
    tax_regime_type character(3) NOT NULL,
    fiscal character(4) NOT NULL,
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.employee_tax_regime OWNER TO postgres;

--
-- Name: employee_tax_regime_emp_tax_regime_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_tax_regime_emp_tax_regime_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_tax_regime_emp_tax_regime_id_seq OWNER TO postgres;

--
-- Name: employee_tax_regime_emp_tax_regime_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_tax_regime_emp_tax_regime_id_seq OWNED BY public.employee_tax_regime.emp_tax_regime_id;


--
-- Name: investment_limit_xref; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investment_limit_xref (
    section character varying(10) NOT NULL,
    investment_limit integer NOT NULL,
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.investment_limit_xref OWNER TO postgres;

--
-- Name: investment_via_xref; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investment_via_xref (
    section character varying(10) NOT NULL,
    investment_type character varying(50) NOT NULL,
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.investment_via_xref OWNER TO postgres;

--
-- Name: it_slab; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_slab (
    it_slab_id integer NOT NULL,
    lower_bound integer NOT NULL,
    upper_bound integer NOT NULL,
    tax_regime_type character(3) NOT NULL,
    tax_rate integer NOT NULL,
    status character varying(10) NOT NULL,
    notes character varying(100),
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL,
    fixed_amount integer
);


ALTER TABLE public.it_slab OWNER TO postgres;

--
-- Name: it_slab_it_slab_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_slab_it_slab_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.it_slab_it_slab_id_seq OWNER TO postgres;

--
-- Name: it_slab_it_slab_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_slab_it_slab_id_seq OWNED BY public.it_slab.it_slab_id;


--
-- Name: payroll_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_options (
    option_key character varying(50) NOT NULL,
    option_value character varying(50) NOT NULL,
    option_description character varying(100),
    row_insert_by character varying(50) NOT NULL,
    row_insert_date timestamp without time zone NOT NULL,
    row_update_by character varying(50) NOT NULL,
    row_update_date timestamp without time zone NOT NULL
);


ALTER TABLE public.payroll_options OWNER TO postgres;

--
-- Name: employee_ctc emp_ctc_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_ctc ALTER COLUMN emp_ctc_id SET DEFAULT nextval('public.employee_ctc_emp_ctc_id_seq'::regclass);


--
-- Name: employee_deductions emp_deduction_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_deductions ALTER COLUMN emp_deduction_id SET DEFAULT nextval('public.employee_deductions_emp_deduction_id_seq'::regclass);


--
-- Name: employee_investment_declaration emp_invest_decl_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_investment_declaration ALTER COLUMN emp_invest_decl_id SET DEFAULT nextval('public.employee_investment_declaration_emp_invest_decl_id_seq'::regclass);


--
-- Name: employee_investment_proof emp_invest_proof_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_investment_proof ALTER COLUMN emp_invest_proof_id SET DEFAULT nextval('public.employee_investment_proof_emp_invest_proof_id_seq'::regclass);


--
-- Name: employee_tax_regime emp_tax_regime_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_tax_regime ALTER COLUMN emp_tax_regime_id SET DEFAULT nextval('public.employee_tax_regime_emp_tax_regime_id_seq'::regclass);


--
-- Name: it_slab it_slab_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_slab ALTER COLUMN it_slab_id SET DEFAULT nextval('public.it_slab_it_slab_id_seq'::regclass);


--
-- Data for Name: ctc_structure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ctc_structure (ctc_component, type, taxable, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
BASIC	FIXED	Y	AMAN	2021-03-26 10:00:09.602336	AMAN	2021-03-26 10:00:09.602336
HRA	FIXED	Y	AMAN	2021-03-28 09:48:01.641362	AMAN	2021-03-28 09:48:01.641362
STD ALLOWANCE	FIXED	Y	AMAN	2021-03-28 09:48:12.912934	AMAN	2021-03-28 09:48:12.912934
SPECIAL ALLOWANCE	FIXED	Y	AMAN	2021-03-28 09:48:19.950893	AMAN	2021-03-28 09:48:19.950893
WELFARE	VARIABLE	N	AMAN	2021-03-28 09:51:13.180745	AMAN	2021-03-28 09:51:13.180745
FOOD COUPON	VARIABLE	N	AMAN	2021-03-28 09:51:23.854406	AMAN	2021-03-28 09:51:23.854406
\.


--
-- Data for Name: deductions_xref; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deductions_xref (deduction, deduction_limit, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
PAYTM	2000	AMAN	2021-03-26 10:24:32.148766	AMAN	2021-03-26 10:24:32.148766
PF	100000	AMAN	2021-03-28 11:07:41.510552	AMAN	2021-03-28 11:07:41.510552
\.


--
-- Data for Name: employee_ctc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_ctc (emp_ctc_id, employee_id, ctc_component, amount, status, fiscal, notes, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
1	GSI-123	BASIC	600000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:57:15.450914	AMAN	2021-03-28 09:57:15.450914
2	GSI-123	HRA	600000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:57:23.808506	AMAN	2021-03-28 09:57:23.808506
3	GSI-123	SPECIAL ALLOWANCE	300000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:57:40.005761	AMAN	2021-03-28 09:57:40.005761
5	GSI-123	WELFARE	300000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:58:25.198672	AMAN	2021-03-28 09:58:25.198672
6	GSI-123	FOOD COUPON	200000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:58:43.306024	AMAN	2021-03-28 09:58:43.306024
7	GSI-333	BASIC	600000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:59:11.384064	AMAN	2021-03-28 09:59:11.384064
9	GSI-333	SPECIAL ALLOWANCE	200000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:59:37.235645	AMAN	2021-03-28 09:59:37.235645
10	GSI-333	STD ALLOWANCE	600000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:59:57.905454	AMAN	2021-03-28 09:59:57.905454
11	GSI-333	WELFARE	600000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 10:00:15.98358	AMAN	2021-03-28 10:00:15.98358
4	GSI-123	STD ALLOWANCE	800000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:57:48.479161	AMAN	2021-03-28 09:57:48.479161
8	GSI-333	HRA	100000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 09:59:25.571814	AMAN	2021-03-28 09:59:25.571814
12	GSI-999	BASIC	420000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 12:58:41.212424	AMAN	2021-03-28 12:58:41.212424
13	GSI-999	HRA	96000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 12:58:57.955583	AMAN	2021-03-28 12:58:57.955583
14	GSI-999	STD ALLOWANCE	39996	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 12:59:28.115395	AMAN	2021-03-28 12:59:28.115395
15	GSI-999	SPECIAL ALLOWANCE	216000	ACTIVE	2021	STANDARD APPRAISAL 10%	AMAN	2021-03-28 12:59:54.903002	AMAN	2021-03-28 12:59:54.903002
\.


--
-- Data for Name: employee_deductions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_deductions (emp_deduction_id, employee_id, deduction, amount, status, fiscal, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
0	GSI-123	PAYTM	24000	APPLIED	2021	AMAN	2021-03-26 11:13:38.481117	AMAN	2021-03-26 11:13:38.481117
1	GSI-123	PF	10200	APPLIED	2021	AMAN	2021-03-28 11:29:26.193734	AMAN	2021-03-28 11:29:26.193734
3	GSI-333	PF	12200	APPLIED	2021	AMAN	2021-03-28 11:29:44.479823	AMAN	2021-03-28 11:29:44.479823
4	GSI-999	PAYTM	24000	APPLIED	2021	AMAN	2021-03-28 13:01:26.803851	AMAN	2021-03-28 13:01:26.803851
5	GSI-999	PF	24000	APPLIED	2021	AMAN	2021-03-28 13:01:35.463703	AMAN	2021-03-28 13:01:35.463703
\.


--
-- Data for Name: employee_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_details (employee_id, emp_fname, emp_lname, status, row_insert_by, row_insert_date, row_update_by, row_update_date, residential_address, city_type) FROM stdin;
GSI-888	AMIT	SHARMA	ACTIVE	AMAN	2021-03-28 00:16:35.323296	AMAN	2021-03-28 00:16:35.323296	\N	\N
GSI-123	AMAN	AGGARWAL	ACTIVE	AMAN	2021-03-26 10:26:40.447999	AMAN	2021-03-26 10:26:40.447999	RANDOM SHIZ	M
GSI-333	SEEMA	CHAUHAN	ACTIVE	AMAN	2021-03-28 00:16:21.775062	AMAN	2021-03-28 00:16:21.775062	MORE RANDOM SHIZ	N
GSI-999	VAIBHAV	KHURANA	ACTIVE	AMAN	2021-03-28 00:16:48.849052	AMAN	2021-03-28 00:16:48.849052	\N	M
\.


--
-- Data for Name: employee_investment_declaration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_investment_declaration (emp_invest_decl_id, employee_id, section, investment_type, amount, fiscal, status, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
0	GSI-123	80C	FIXED DEPOSIT	10000	2020	ACTIVE	AMAN	2021-03-26 10:40:30.688763	AMAN	2021-03-26 10:40:30.688763
2	GSI-123	80C	PUBLIC PROVIDENT FUND	90000	2020	ACTIVE	AMAN	2021-03-28 11:05:04.756986	AMAN	2021-03-28 11:05:04.756986
3	GSI-123	80CCD	NATIONAL PENSION SCHEME	10000	2020	ACTIVE	AMAN	2021-03-28 11:05:49.560207	AMAN	2021-03-28 11:05:49.560207
4	GSI-333	80CCD	NATIONAL PENSION SCHEME	80000	2020	ACTIVE	AMAN	2021-03-28 11:06:04.207572	AMAN	2021-03-28 11:06:04.207572
5	GSI-123	10(13A)	HRA	240000	2020	ACTIVE	AMAN	2021-03-28 11:38:15.379583	AMAN	2021-03-28 11:38:15.379583
6	GSI-333	10(13A)	HRA	200000	2020	ACTIVE	AMAN	2021-03-28 11:38:29.40762	AMAN	2021-03-28 11:38:29.40762
7	GSI-999	10(13A)	HRA	120000	2020	ACTIVE	AMAN	2021-03-28 13:02:39.56443	AMAN	2021-03-28 13:02:39.56443
8	GSI-999	80C	FIXED DEPOSIT	96000	2020	ACTIVE	AMAN	2021-03-28 13:04:34.464798	AMAN	2021-03-28 13:04:34.464798
10	GSI-999	80C	LIFE INSURANCE PREMIUM	20000	2020	ACTIVE	AMAN	2021-03-28 13:09:34.292618	AMAN	2021-03-28 13:09:34.292618
11	GSI-999	80D	MEDICAL INSURANCE PREMIUM	2000	2020	ACTIVE	AMAN	2021-03-28 13:11:19.713931	AMAN	2021-03-28 13:11:19.713931
9	GSI-999	80C	PUBLIC PROVIDENT FUND	34000	2020	ACTIVE	AMAN	2021-03-28 13:06:47.357769	AMAN	2021-03-28 13:06:47.357769
\.


--
-- Data for Name: employee_investment_proof; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_investment_proof (emp_invest_proof_id, emp_invest_decl_id, proof_1, proof_2, proof_3, status, notes, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
0	0	PROOF LINK	\N	\N	APPROVED	\N	AMAN	2021-03-26 10:45:56.785542	AMAN	2021-03-26 10:45:56.785542
\.


--
-- Data for Name: employee_tax_regime; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_tax_regime (emp_tax_regime_id, employee_id, tax_regime_type, fiscal, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
1	GSI-123	OLD	2021	AMAN	2021-03-28 10:26:59.596389	AMAN	2021-03-28 10:26:59.596389
2	GSI-333	OLD	2021	AMAN	2021-03-28 10:27:12.56293	AMAN	2021-03-28 10:27:12.56293
\.


--
-- Data for Name: investment_limit_xref; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investment_limit_xref (section, investment_limit, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
80C	150000	AMAN	2021-03-26 10:13:47.671396	AMAN	2021-03-26 10:13:47.671396
80CCD	150000	AMAN	2021-03-28 11:02:57.01655	AMAN	2021-03-28 11:02:57.01655
80D	150000	AMAN	2021-03-28 11:03:25.112932	AMAN	2021-03-28 11:03:25.112932
10(13A)	1000000000	AMAN	2021-03-28 11:35:45.493617	AMAN	2021-03-28 11:35:45.493617
\.


--
-- Data for Name: investment_via_xref; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.investment_via_xref (section, investment_type, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
80C	FIXED DEPOSIT	AMAN	2021-03-26 10:16:47.925924	AMAN	2021-03-26 10:16:47.925924
80C	PUBLIC PROVIDENT FUND	AMAN	2021-03-28 11:01:57.957735	AMAN	2021-03-28 11:01:57.957735
80CCD	NATIONAL PENSION SCHEME	AMAN	2021-03-28 11:04:08.70146	AMAN	2021-03-28 11:04:08.70146
80D	MEDICAL INSURANCE PREMIUM	AMAN	2021-03-28 11:04:31.205432	AMAN	2021-03-28 11:04:31.205432
10(13A)	HRA	AMAN	2021-03-28 11:36:24.117386	AMAN	2021-03-28 11:36:24.117386
80C	LIFE INSURANCE PREMIUM	AMAN	2021-03-28 13:09:03.969303	AMAN	2021-03-28 13:09:03.969303
\.


--
-- Data for Name: it_slab; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_slab (it_slab_id, lower_bound, upper_bound, tax_regime_type, tax_rate, status, notes, row_insert_by, row_insert_date, row_update_by, row_update_date, fixed_amount) FROM stdin;
0	0	250000	NEW	0	ACTIVE	NEW TAX REGIME WITHOUT EXEMPTIONS	AMAN	2021-03-26 10:10:15.137556	AMAN	2021-03-26 10:10:15.137556	\N
1	250001	500000	NEW	5	ACTIVE	NEW TAX REGIME WITHOUT EXEMPTIONS	AMAN	2021-03-26 10:11:51.503064	AMAN	2021-03-26 10:11:51.503064	\N
2	500001	750000	NEW	10	ACTIVE	NEW TAX REGIME WITHOUT EXEMPTIONS	AMAN	2021-03-28 10:10:28.823536	AMAN	2021-03-28 10:10:28.823536	\N
3	750001	1000000	NEW	15	ACTIVE	NEW TAX REGIME WITHOUT EXEMPTIONS	AMAN	2021-03-28 10:11:36.089358	AMAN	2021-03-28 10:11:36.089358	\N
4	1000001	1250000	NEW	20	ACTIVE	NEW TAX REGIME WITHOUT EXEMPTIONS	AMAN	2021-03-28 10:12:02.512305	AMAN	2021-03-28 10:12:02.512305	\N
5	1250001	1500000	NEW	25	ACTIVE	NEW TAX REGIME WITHOUT EXEMPTIONS	AMAN	2021-03-28 10:12:21.607153	AMAN	2021-03-28 10:12:21.607153	\N
6	1500001	1000000000	NEW	30	ACTIVE	NEW TAX REGIME WITHOUT EXEMPTIONS	AMAN	2021-03-28 10:15:26.220951	AMAN	2021-03-28 10:15:26.220951	\N
11	1000001	1000000000	OLD	30	ACTIVE	OLD TAX REGIME WITH EXEMPTIONS	AMAN	2021-03-28 10:22:34.326658	AMAN	2021-03-28 10:22:34.326658	\N
8	0	250000	OLD	0	ACTIVE	OLD TAX REGIME WITH EXEMPTIONS	AMAN	2021-03-28 10:21:03.544792	AMAN	2021-03-28 10:21:03.544792	0
9	250001	500000	OLD	5	ACTIVE	OLD TAX REGIME WITH EXEMPTIONS	AMAN	2021-03-28 10:21:25.136447	AMAN	2021-03-28 10:21:25.136447	12500
10	500001	1000000	OLD	20	ACTIVE	OLD TAX REGIME WITH EXEMPTIONS	AMAN	2021-03-28 10:21:36.396708	AMAN	2021-03-28 10:21:36.396708	100000
\.


--
-- Data for Name: payroll_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll_options (option_key, option_value, option_description, row_insert_by, row_insert_date, row_update_by, row_update_date) FROM stdin;
CTC_COMPONENT	BASIC	BASIC COMPONENT OF CTC	AMAN	2021-03-26 10:05:55.541248	AMAN	2021-03-26 10:05:55.541248
\.


--
-- Name: employee_ctc_emp_ctc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_ctc_emp_ctc_id_seq', 1, false);


--
-- Name: employee_deductions_emp_deduction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_deductions_emp_deduction_id_seq', 1, false);


--
-- Name: employee_investment_declaration_emp_invest_decl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_investment_declaration_emp_invest_decl_id_seq', 1, false);


--
-- Name: employee_investment_proof_emp_invest_proof_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_investment_proof_emp_invest_proof_id_seq', 1, false);


--
-- Name: employee_tax_regime_emp_tax_regime_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_tax_regime_emp_tax_regime_id_seq', 1, false);


--
-- Name: it_slab_it_slab_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_slab_it_slab_id_seq', 11, true);


--
-- Name: ctc_structure ctc_structure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ctc_structure
    ADD CONSTRAINT ctc_structure_pkey PRIMARY KEY (ctc_component);


--
-- Name: deductions_xref deductions_xref_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deductions_xref
    ADD CONSTRAINT deductions_xref_pkey PRIMARY KEY (deduction);


--
-- Name: employee_ctc employee_ctc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_ctc
    ADD CONSTRAINT employee_ctc_pkey PRIMARY KEY (emp_ctc_id);


--
-- Name: employee_deductions employee_deductions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT employee_deductions_pkey PRIMARY KEY (emp_deduction_id);


--
-- Name: employee_details employee_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_details
    ADD CONSTRAINT employee_details_pkey PRIMARY KEY (employee_id);


--
-- Name: employee_investment_declaration employee_investment_declaration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_investment_declaration
    ADD CONSTRAINT employee_investment_declaration_pkey PRIMARY KEY (emp_invest_decl_id);


--
-- Name: employee_investment_proof employee_investment_proof_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_investment_proof
    ADD CONSTRAINT employee_investment_proof_pkey PRIMARY KEY (emp_invest_proof_id);


--
-- Name: employee_tax_regime employee_tax_regime_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_tax_regime
    ADD CONSTRAINT employee_tax_regime_pkey PRIMARY KEY (emp_tax_regime_id);


--
-- Name: investment_limit_xref investment_limit_xref_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_limit_xref
    ADD CONSTRAINT investment_limit_xref_pkey PRIMARY KEY (section);


--
-- Name: investment_via_xref investment_via_xref_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_via_xref
    ADD CONSTRAINT investment_via_xref_pkey PRIMARY KEY (section, investment_type);


--
-- Name: it_slab it_slab_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_slab
    ADD CONSTRAINT it_slab_pkey PRIMARY KEY (it_slab_id);


--
-- Name: payroll_options payroll_options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_options
    ADD CONSTRAINT payroll_options_pkey PRIMARY KEY (option_key, option_value);


--
-- Name: employee_ctc fk_emp_ctc_component; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_ctc
    ADD CONSTRAINT fk_emp_ctc_component FOREIGN KEY (ctc_component) REFERENCES public.ctc_structure(ctc_component) ON DELETE CASCADE;


--
-- Name: employee_ctc fk_emp_ctc_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_ctc
    ADD CONSTRAINT fk_emp_ctc_id FOREIGN KEY (employee_id) REFERENCES public.employee_details(employee_id) ON DELETE CASCADE;


--
-- Name: employee_deductions fk_emp_deduction; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT fk_emp_deduction FOREIGN KEY (deduction) REFERENCES public.deductions_xref(deduction) ON DELETE CASCADE;


--
-- Name: employee_deductions fk_emp_deduction_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_deductions
    ADD CONSTRAINT fk_emp_deduction_id FOREIGN KEY (employee_id) REFERENCES public.employee_details(employee_id) ON DELETE CASCADE;


--
-- Name: employee_investment_declaration fk_emp_invest_decl; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_investment_declaration
    ADD CONSTRAINT fk_emp_invest_decl FOREIGN KEY (section, investment_type) REFERENCES public.investment_via_xref(section, investment_type) ON DELETE CASCADE;


--
-- Name: employee_investment_declaration fk_emp_invest_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_investment_declaration
    ADD CONSTRAINT fk_emp_invest_id FOREIGN KEY (employee_id) REFERENCES public.employee_details(employee_id) ON DELETE CASCADE;


--
-- Name: employee_investment_proof fk_emp_invest_proof; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_investment_proof
    ADD CONSTRAINT fk_emp_invest_proof FOREIGN KEY (emp_invest_decl_id) REFERENCES public.employee_investment_declaration(emp_invest_decl_id) ON DELETE CASCADE;


--
-- Name: investment_via_xref fk_investment_xref; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investment_via_xref
    ADD CONSTRAINT fk_investment_xref FOREIGN KEY (section) REFERENCES public.investment_limit_xref(section) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

